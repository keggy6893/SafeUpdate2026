SafeUpdate2026 2026.1-r34-dev2
===============================

Ziel: Recovery fuer normale Nutzer ohne Telnet-Schrittfolge.

r34-dev2:
- vor Update automatischer Multiboot-/Dateisystem-/Backup-Preflight
- EXT4/JBD2-Kernelfehler blockieren das Update
- nach erfolgreichem Update Recovery-Plan in /boot
- Recovery-Laufzeit wird in den verifizierten Sicherheits-Slot gespiegelt
- VU+ Duo 4K SE: externer BootGuard ueberwacht den ersten Start nach Update
- Enigma2 Crash-Schleife -> einmaliger automatischer Start des Sicherheits-Slots
- Sicherheits-Slot zeigt automatisch eine JA/NEIN-Wiederherstellung an
- Wiederherstellung arbeitet nur auf dem inaktiven Quellslot
- temporäre Doppelkopie + Verifikation, bevor der defekte Slot ersetzt wird
- nach erfolgreicher Wiederherstellung STARTUP_ONCE zurueck auf den Quellslot

WICHTIG:
- automatischer Crash-Fallback in dev2 ist nur fuer das validierte VU+ Duo 4K SE Layout aktiviert
- separate Kernelpartitionen bleiben im Recovery-Helfer weiterhin blockiert
- Dateisystemreparatur (fsck) wird NICHT automatisch auf einem gemounteten Rootgeraet ausgefuehrt
