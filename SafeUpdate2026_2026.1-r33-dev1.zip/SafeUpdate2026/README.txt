SafeUpdate2026 2026.1-r33-dev1
==============================

Entwicklungs-/Hardware-Teststand auf Basis von r32.

Enthalten aus r32:
- Multiboot-sicheres Backup vor OpenATV-Update
- GigaBlue UHD Trio 4K Kernel-/Slot-Schutz
- internes eMMC-Backup als Fallback ohne freien Slot
- Killswitch Taste 0
- Notfall-Wiederherstellung Taste 9 aus einem anderen Slot
- belegte Slots und Recovery werden nicht als Backup-Ziel ueberschrieben

Neu in r33-dev1:
- automatische Backup-Pruefung alle 24 Stunden
- Vollbackup nur wenn sich Image-/Paketstand geaendert hat
- altes verifiziertes Backup bleibt bis zur Verifikation der neuen Kopie erhalten
- sichere Slot-Rotation mit .safeupdate-new / .safeupdate-old
- GigaBlue-Rotation sichert vor dem Kernel-Tausch auch den alten Ziel-Kernel temporaer
- internes eMMC-Backup kann ebenfalls sicher rotiert werden
- Taste 7: Rotation sofort testen
- Taste 8: 24h-Auto-Rotation EIN/AUS
- Enigma2-Hintergrunddienst: Plugin muss fuer die 24h-Pruefung nicht offen bleiben
- nach erfolgreichem OpenATV-Update bleibt das Vor-Update-Backup mindestens 24h erhalten
