SafeUpdate2026 2026.1-r21
==========================

Sicherheitsupdate auf Basis des real getesteten r14/r15-Stands.

Neu in r16
----------
1. Fortschrittsbereich optisch nachgebessert.
   - Klarer Abstand unter dem Backup-Button
   - Balken deutlich breiter und hoeher
   - Prozentzahl mittig direkt im Balken
   - Statuszeile sauber unter dem Balken
   - Keine Aenderung an Backup-/Slot-Logik

Aus r15 enthalten
-----------------
1. Großer sichtbarer Backup-Fortschritt im Backup-Bereich.
   - Byte-basierte Kopierfortschrittsmessung per du -sk
   - 0-92 % während des Kopierens
   - 95-99 % Integritäts-/Kernelprüfung
   - 100 % erst nach erfolgreicher Verifikation

2. Full-Mount-Fix für KEXEC/rootsubdir.
   - Wenn /dev/sda1 bereits rw als laufendes Root-Dateisystem eingebunden ist,
     wird der zweite Full-View mit demselben rw-Modus und explizitem Dateisystemtyp erstellt.
   - Behebt den r14-Fall: "kein eindeutig verifizierter freier Slot" nach Neustart.

3. Stale-Backup-Schutz.
   - Ein gespeichertes verified=true reicht nicht mehr.
   - Beim Öffnen wird das Backup physisch erneut geprüft:
     zImage, /etc/image-version, /sbin/init und /usr/bin/enigma2.
   - Fehlt das Backup, wird die Update-Freigabe sofort entzogen.

4. OpenATV-Löschreste.
   - Ein wirklich leeres linuxrootfsN-Verzeichnis wird als leerer Slot-Rest erkannt.
   - Nur ein strikt leeres reales Verzeichnis darf nach Nutzerbestätigung per rmdir entfernt werden.
   - Teilweise/unklare Slot-Inhalte bleiben weiterhin strikt gesperrt.

Unverändert
-----------
- STARTUP_N-Dateien werden beim Backup NICHT überschrieben.
- Bestehende belegte Slots werden niemals überschrieben.
- KEXEC-Hash und Kernel-HOLDs bleiben Pflicht.
- Update bleibt bis zu einem physisch verifizierten Backup gesperrt.
- Das bestehende SafeUpdate2026 Layout/Branding bleibt erhalten.

Testziel
--------
Aktiver Slot: 8
Backup-Ziel: z. B. Slot 11
Nach erfolgreichem Backup sollte der Fortschritt 100 % zeigen und das Update freigeben.


r17:
- Statuszeile unter dem Backup-Fortschritt gelb hervorgehoben.


r18:
- Aktiven OpenATV-Update-Button niedriger und 10 px nach oben gesetzt.
- Hinweis "Backup verifiziert – Update freigegeben" mit klarem Abstand darunter.
- Fokus-/Buttonflaeche ueberdeckt den Hinweistext nicht mehr.
- Backup-/Slot-/KEXEC-Logik unveraendert zu r17.

r19:
- Update-Bereich grundsaetzlich bereinigt: statischer Button/Hinweis aus dem Hintergrund entfernt.
- Es gibt jetzt genau EINEN dynamischen Update-Button; keine Doppelung/Überlagerung mehr.
- Gesperrt: grauer Button + Hinweis "Wird nach erfolgreichem Backup freigeschaltet."
- Freigegeben: blauer Button + Hinweis "Backup verifiziert – Update freigegeben".
- Backup-/Slot-/KEXEC-Logik unveraendert zu r18.


r21:
- Zielslot-Anzeige verbreitert, damit "Slot 11 – VERIFIZIERT ✓" vollständig sichtbar bleibt.
- Keine Änderung an Backup-, KEXEC-, Slot- oder Update-Logik.


2026.1-r27:
- Receiver-Hersteller/Modell dynamisch erkannt (VU+, Octagon, GigaBlue u.a.)
- VU+-spezifische statische Grafik durch neutrales Receiver-/Schutzmotiv ersetzt
- Backup/KEXEC/Slot/Update-Logik unveraendert gegenueber r23


r27 – Killswitch / sauberes Backup-Löschen
-----------------------------------------
- Taste 0 löscht nach Bestätigung ausschließlich das aktuell von SafeUpdate verifizierte Sicherheitsbackup.
- Der aktive Slot kann niemals gelöscht werden.
- STARTUP_N bleibt erhalten; dadurch wird der Backup-Slot nach erfolgreichem Löschen wieder als FREI erkannt.
- Vor dem Löschen werden State, Slot-Zuordnung, Root-Gerät und die physische Backup-Struktur erneut geprüft.
- Nach erfolgreichem Löschen wird der gespeicherte Backup-Status entfernt und das OpenATV-Update sofort wieder gesperrt.
- Bei einer unvollständigen Löschung wird der Slot ausdrücklich NICHT als frei behandelt.
