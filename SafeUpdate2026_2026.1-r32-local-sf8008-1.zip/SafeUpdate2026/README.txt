SafeUpdate2026 2026.1-r32-local-sf8008-1
=========================================

Hardware-Teststand fuer Octagon SF8008. Kein allgemeines Release.

Verifiziertes SF8008 Layout:
- RootFS: /dev/mmcblk0p16
- Slot 1 Kernel: /dev/mmcblk0p12
- Slot 2 Kernel: /dev/mmcblk0p13
- Slot 3 Kernel: /dev/mmcblk0p14
- Slot 4 Kernel: /dev/mmcblk0p15
- STARTUP_5/6 sind USB und werden nicht als interne eMMC-Ziele verwendet.
- STARTUP_RECOVERY bleibt unangetastet.
