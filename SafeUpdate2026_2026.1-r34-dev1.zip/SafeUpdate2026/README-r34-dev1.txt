SafeUpdate2026 2026.1-r34-dev1
===============================

Entwicklungsstand: Crash-Recovery per Telnet/SSH.

Ablauf bei Enigma2-Dauerloop:
1. init 4
2. safeupdate-recover
3. Sicherheits-Slot im Multiboot-Menü booten
4. dort erneut: init 4
5. safeupdate-recover
6. Wiederherstellung mit JA bestätigen

Sicherheitsregeln:
- laufender Slot wird niemals überschrieben
- nur verified=true / backup_mode=slot
- Quelle/Ziel müssen aus numerischem STARTUP_N eindeutig sein
- Kernel muss in linuxrootfsN/zImage liegen
- separate Kernelpartitionen werden in dev1 blockiert
- neue Kopie wird vollständig verifiziert, bevor der defekte Zielbaum ersetzt wird
- Sicherheits-Slot bleibt unverändert
