# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import re
import json
import hashlib
import subprocess
import glob
import time
from datetime import datetime

from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.ProgressBar import ProgressBar
from enigma import eConsoleAppContainer, eTimer, ePoint
from skin import parseColor

PLUGIN_NAME = "Safe Update 2026"
PLUGIN_VERSION = "2026.1-r34-dev1"

KEXEC_DEVICE = "/dev/mmcblk0p6"
KEXEC_SIZE = 6483040
KEXEC_GOOD_HASH = "361e9dfddcc4e23ec566608ddf22778779256919728b53b00d244466071b2cdf"

KERNEL_PACKAGES = (
    "kernel-4.1.45-1.17",
    "kernel-image-4.1.45-1.17",
    "kernel-image-zimage-4.1.45-1.17",
)

# r30: verified GigaBlue UHD Trio 4K layout from the real test receiver.
GBTRIO4K_KERNEL_PACKAGES = (
    "kernel-4.4.35",
    "kernel-image-4.4.35",
    "kernel-image-uimage-4.4.35",
)
GBTRIO4K_ROOT_DEVICE = "/dev/mmcblk0p16"
GBTRIO4K_KERNEL_DEVICES = {
    1: "/dev/mmcblk0p12",
    2: "/dev/mmcblk0p13",
    3: "/dev/mmcblk0p14",
    4: "/dev/mmcblk0p15",
}

FULL_MOUNT = "/tmp/safeupdate2026-full"
STATE_FILE = "/etc/enigma2/safeupdate2026.json"
LOG_FILE = "/tmp/safeupdate2026.log"
INTERNAL_BACKUP_DIRNAME = "safeupdate2026"
INTERNAL_BACKUP_META = "backup.json"
ROTATION_INTERVAL = 24 * 60 * 60
ROTATION_RETRY_INTERVAL = 60 * 60
ROTATION_TICK_MS = 30 * 60 * 1000
ROTATION_NEW_SUFFIX = ".safeupdate-new"
ROTATION_OLD_SUFFIX = ".safeupdate-old"
ROTATION_NEW_KERNEL_SUFFIX = ".safeupdate-new-kernel.img"
ROTATION_OLD_KERNEL_SUFFIX = ".safeupdate-old-kernel.img"


def read_text(path, default=""):
    try:
        with open(path, "r") as f:
            return f.read()
    except Exception:
        return default


def run_cmd(args):
    try:
        return subprocess.check_output(args, stderr=subprocess.STDOUT).decode("utf-8", "replace")
    except Exception:
        return ""


def image_info():
    data = {}
    for line in read_text("/etc/image-version").splitlines():
        if "=" in line:
            key, val = line.split("=", 1)
            data[key.strip()] = val.strip()
    return data


def cmdline():
    return read_text("/proc/cmdline").strip()


def cmd_value(name, text=None):
    c = cmdline() if text is None else str(text)
    m = re.search(r"(?:^|\s)%s=([^\s]+)" % re.escape(name), c)
    return m.group(1) if m else ""


def machinebuild():
    return cmd_value("MACHINEBUILD").strip().lower()


def oem_name():
    return cmd_value("OEM").strip().lower()


def is_gbtrio4k():
    # /proc/stb/info/model reports dm8000 on the tested receiver, so use cmdline identity.
    return machinebuild() == "gbtrio4k" and oem_name() == "gigablue"


def kernel_packages():
    return GBTRIO4K_KERNEL_PACKAGES if is_gbtrio4k() else KERNEL_PACKAGES


def active_kernel_device():
    value = cmd_value("kernel").strip()
    return os.path.realpath(value) if value.startswith("/dev/") else ""


def expected_kernel_device(slot):
    if not is_gbtrio4k():
        return ""
    try:
        return os.path.realpath(GBTRIO4K_KERNEL_DEVICES[int(slot)])
    except Exception:
        return ""


def current_slot():
    sub = cmd_value("rootsubdir")
    m = re.search(r"(?:^|/)linuxrootfs(\d+)$", sub)
    if m:
        return int(m.group(1))

    kern = cmd_value("kernel")
    m = re.search(r"(?:^|/)linuxrootfs(\d+)/zImage$", kern)
    return int(m.group(1)) if m else None


def root_spec():
    return cmd_value("root")


def resolve_root_spec(spec):
    spec = (spec or "").strip()
    if not spec:
        return ""

    if spec.startswith("/dev/"):
        return os.path.realpath(spec)

    if spec.startswith("UUID="):
        return os.path.realpath(run_cmd(["blkid", "-U", spec[5:]]).strip())

    if spec.startswith("LABEL="):
        return os.path.realpath(run_cmd(["blkid", "-L", spec[6:]]).strip())

    if spec.startswith("PARTUUID="):
        out = run_cmd(["blkid", "-t", "PARTUUID=%s" % spec[9:], "-o", "device"]).strip()
        return os.path.realpath(out)

    return ""


def root_device():
    return resolve_root_spec(root_spec())


def active_rootsubdir():
    raw = cmd_value("rootsubdir").strip().strip("/")
    if not raw:
        return ""
    norm = os.path.normpath(raw)
    if norm == ".." or norm.startswith("../"):
        return ""
    return norm


def safe_rootsubdir(raw, slot):
    raw = (raw or "").strip().strip("/")
    if not raw:
        return ""
    norm = os.path.normpath(raw)
    if norm == ".." or norm.startswith("../"):
        return ""
    if norm != raw:
        return ""
    m = re.search(r"(?:^|/)linuxrootfs(\d+)$", norm)
    if not m or int(m.group(1)) != int(slot):
        return ""
    return norm


def parse_startup_text(slot, text, path=""):
    root = ""
    rootsubdir = ""
    kernel = ""

    m = re.search(r"(?:^|[\s\'\"])root=([^\s\'\"]+)", text or "")
    if m:
        root = m.group(1)
    m = re.search(r"(?:^|[\s\'\"])rootsubdir=([^\s\'\"]+)", text or "")
    if m:
        rootsubdir = m.group(1)
    m = re.search(r"(?:^|[\s\'\"])kernel=([^\s\'\"]+)", text or "")
    if m:
        kernel = m.group(1)

    rootsubdir = safe_rootsubdir(rootsubdir, slot)
    if not root or not rootsubdir or not kernel:
        return None

    kernel_norm = os.path.normpath(kernel.strip().lstrip("/"))
    expected_tree_kernel = os.path.join(rootsubdir, "zImage")
    kernel_in_tree = kernel_norm == expected_tree_kernel
    kernel_device = os.path.realpath(kernel) if kernel.startswith("/dev/") else ""
    if not kernel_in_tree and not kernel_device:
        return None

    dev = resolve_root_spec(root)
    if not dev:
        return None

    return {
        "slot": int(slot),
        "path": path,
        "root_spec": root,
        "root_device": dev,
        "rootsubdir": rootsubdir,
        "kernel": kernel,
        "kernel_device": kernel_device,
        "kernel_in_tree": kernel_in_tree,
    }


def startup_slots():
    result = {}
    for path in sorted(glob.glob("/boot/STARTUP_*")):
        base = os.path.basename(path)
        m = re.match(r"^STARTUP_(\d+)$", base)
        if not m:
            continue
        slot = int(m.group(1))
        info = parse_startup_text(slot, read_text(path), path)
        if info is not None:
            result[slot] = info
    return result


def same_device(a, b):
    a = os.path.realpath(a or "")
    b = os.path.realpath(b or "")
    return bool(a and b and a == b)


def _decode_mount_field(value):
    return (value
            .replace("\\040", " ")
            .replace("\\011", "\t")
            .replace("\\012", "\n")
            .replace("\\134", "\\"))


def mount_entries():
    rows = []
    for line in read_text("/proc/mounts").splitlines():
        parts = line.split()
        if len(parts) < 4:
            continue
        rows.append({
            "source": _decode_mount_field(parts[0]),
            "mountpoint": _decode_mount_field(parts[1]),
            "fstype": parts[2],
            "options": parts[3].split(","),
        })
    return rows


def slot_root_tree_valid(path):
    common = (
        os.path.isdir(path) and
        os.path.isfile(os.path.join(path, "etc", "image-version")) and
        os.path.exists(os.path.join(path, "sbin", "init")) and
        os.path.isfile(os.path.join(path, "usr", "bin", "enigma2"))
    )
    if not common:
        return False
    if is_gbtrio4k():
        return True
    return os.path.isfile(os.path.join(path, "zImage"))


def _full_mount_is_valid(mountpoint):
    sub = active_rootsubdir()
    if not mountpoint or not sub:
        return False
    return slot_root_tree_valid(os.path.join(mountpoint, sub))


def _mount_entry_for_path(path):
    path = os.path.realpath(path)
    for row in mount_entries():
        if os.path.realpath(row["mountpoint"]) == path:
            return row
    return None


def _device_mount_profile(dev):
    fstype = ""
    rw_mounted = False
    for row in mount_entries():
        if not same_device(row.get("source"), dev):
            continue
        if not fstype and row.get("fstype"):
            fstype = row.get("fstype")
        if "rw" in row.get("options", []):
            rw_mounted = True
    return fstype, rw_mounted


def ensure_full_mount(writable=False):
    """Return a verified full-filesystem view of the active multiboot device."""
    dev = root_device()
    sub = active_rootsubdir()
    if not dev or not sub:
        return ""

    if os.path.ismount(FULL_MOUNT):
        row = _mount_entry_for_path(FULL_MOUNT)
        if not row or not same_device(row["source"], dev) or not _full_mount_is_valid(FULL_MOUNT):
            return ""
        if writable and "ro" in row["options"]:
            if subprocess.call(["mount", "-o", "remount,rw", FULL_MOUNT]) != 0:
                return ""
        return FULL_MOUNT

    for row in mount_entries():
        if not same_device(row["source"], dev):
            continue
        mp = row["mountpoint"]
        if not _full_mount_is_valid(mp):
            continue
        if writable and "ro" in row["options"]:
            continue
        return mp

    try:
        if not os.path.isdir(FULL_MOUNT):
            os.makedirs(FULL_MOUNT)
    except Exception:
        return ""

    # KEXEC rootsubdir systems often have this same device already mounted rw
    # as '/'. A second ro mount can fail with EBUSY, so discovery uses the same
    # rw mode if needed. Merely mounting rw does not change files.
    fstype, dev_rw = _device_mount_profile(dev)
    mode = "rw" if (writable or dev_rw) else "ro"
    args = ["mount"]
    if fstype:
        args += ["-t", fstype]
    args += ["-o", mode, dev, FULL_MOUNT]
    if subprocess.call(args) != 0:
        return ""

    if not _full_mount_is_valid(FULL_MOUNT):
        try:
            subprocess.call(["umount", FULL_MOUNT])
        except Exception:
            pass
        return ""
    return FULL_MOUNT


def active_source_path(mountpoint=None):
    mp = mountpoint or ensure_full_mount(False)
    sub = active_rootsubdir()
    if not mp or not sub:
        return ""
    return os.path.join(mp, sub)


def compatible_startup_slots():
    dev = root_device()
    result = {}
    if not dev:
        return result
    for slot, info in startup_slots().items():
        if same_device(info.get("root_device"), dev):
            result[slot] = info
    return result


def slot_path(slot, mountpoint=None):
    info = compatible_startup_slots().get(int(slot))
    if not info:
        return ""
    mp = mountpoint or ensure_full_mount(False)
    if not mp:
        return ""
    return os.path.join(mp, info["rootsubdir"])


def is_strictly_empty_dir(path):
    try:
        return os.path.isdir(path) and not os.path.islink(path) and len(os.listdir(path)) == 0
    except Exception:
        return False


def slot_is_verified_free(info, mountpoint):
    if not info or not mountpoint:
        return False
    path = os.path.join(mountpoint, info["rootsubdir"])
    # OpenATV Delete can leave an empty linuxrootfsN directory behind.
    # Only a completely empty real directory is reusable; partial images stay blocked.
    return (not os.path.lexists(path)) or is_strictly_empty_dir(path)


def free_slots():
    """
    A slot is offered only when:
    - a numeric /boot/STARTUP_N exists and passes strict validation,
    - it belongs to the same multiboot root device as the running slot,
    - the running slot is verifiably visible in a full-filesystem view,
    - the target linuxrootfsN path does not exist, or is a strictly empty OpenATV delete-remnant.
    """
    active = current_slot()
    mp = ensure_full_mount(False)
    if active is None or not mp:
        return []

    src = active_source_path(mp)
    if not src or not os.path.isdir(src):
        return []

    result = []
    for slot, info in sorted(compatible_startup_slots().items()):
        if slot == active:
            continue
        if slot_is_verified_free(info, mp):
            result.append(slot)
    return result


def tree_size_bytes(path):
    try:
        out = subprocess.check_output(["du", "-sk", path], stderr=subprocess.STDOUT)
        kb = int(out.decode("utf-8", "replace").split()[0])
        return kb * 1024
    except Exception:
        return 0


def filesystem_free_bytes(path):
    try:
        st = os.statvfs(path)
        return int(st.f_bavail) * int(st.f_frsize)
    except Exception:
        return 0


def sha256_prefix(path, size=None):
    h = hashlib.sha256()
    try:
        with open(path, "rb", buffering=0) as f:
            left = size
            while True:
                n = 1024 * 1024
                if left is not None:
                    if left <= 0:
                        break
                    n = min(n, left)
                chunk = f.read(n)
                if not chunk:
                    break
                h.update(chunk)
                if left is not None:
                    left -= len(chunk)
        return h.hexdigest()
    except Exception:
        return ""


def gigablue_kernel_layout_ok():
    if not is_gbtrio4k():
        return False
    slot = current_slot()
    if slot not in GBTRIO4K_KERNEL_DEVICES:
        return False
    if os.path.realpath(root_device() or "") != os.path.realpath(GBTRIO4K_ROOT_DEVICE):
        return False
    if active_kernel_device() != expected_kernel_device(slot):
        return False
    slots = startup_slots()
    for number, device in sorted(GBTRIO4K_KERNEL_DEVICES.items()):
        info = slots.get(number)
        if not info:
            return False
        if info.get("rootsubdir") != "linuxrootfs%d" % number:
            return False
        if os.path.realpath(info.get("root_device") or "") != os.path.realpath(GBTRIO4K_ROOT_DEVICE):
            return False
        if os.path.realpath(info.get("kernel_device") or "") != os.path.realpath(device):
            return False
    return True


def kexec_ok():
    # VU+ retains its established KEXEC hash check. GigaBlue verifies native kernel slots.
    if is_gbtrio4k():
        return gigablue_kernel_layout_ok()
    return sha256_prefix(KEXEC_DEVICE, KEXEC_SIZE) == KEXEC_GOOD_HASH


def kernel_device_for_slot(slot):
    try:
        info = startup_slots().get(int(slot))
    except Exception:
        info = None
    if not info:
        return ""
    return os.path.realpath(info.get("kernel_device") or "")


def slot_backup_valid(slot, path, expected_kernel_hash=""):
    if not slot_root_tree_valid(path):
        return False
    if not is_gbtrio4k():
        return True
    kernel_dev = kernel_device_for_slot(slot)
    if not kernel_dev or not os.path.exists(kernel_dev):
        return False
    target_hash = sha256_prefix(kernel_dev)
    if not target_hash:
        return False
    if expected_kernel_hash:
        return target_hash == expected_kernel_hash
    source_dev = active_kernel_device()
    source_hash = sha256_prefix(source_dev) if source_dev else ""
    return bool(source_hash and target_hash == source_hash)


def hdd_ok():
    for line in read_text("/proc/mounts").splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "/media/usb":
            return True
    return False



def block_device_size(path):
    try:
        value = run_cmd(["blockdev", "--getsize64", path]).strip()
        return int(value)
    except Exception:
        return 0


def read_json_file(path):
    try:
        with open(path, "r") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_json_file(path, data):
    tmp = path + ".tmp"
    try:
        with open(tmp, "w") as f:
            json.dump(data, f, indent=2, sort_keys=True)
            f.flush()
            try:
                os.fsync(f.fileno())
            except Exception:
                pass
        os.rename(tmp, path)
        return True
    except Exception:
        try:
            if os.path.exists(tmp):
                os.unlink(tmp)
        except Exception:
            pass
        return False


def internal_backup_base(mountpoint):
    if not mountpoint:
        return ""
    return os.path.join(mountpoint, INTERNAL_BACKUP_DIRNAME)


def internal_backup_dir(source_slot, mountpoint):
    try:
        source_slot = int(source_slot)
    except Exception:
        return ""
    if source_slot <= 0 or source_slot > 99 or not mountpoint:
        return ""
    return os.path.join(internal_backup_base(mountpoint), "slot%d" % source_slot)


def internal_backup_path_is_safe(path, source_slot, mountpoint):
    expected = internal_backup_dir(source_slot, mountpoint)
    if not expected or not path or not mountpoint:
        return False
    mp_real = os.path.realpath(mountpoint)
    base = internal_backup_base(mountpoint)
    expected_real = os.path.realpath(expected)
    path_real = os.path.realpath(path)
    if path_real != expected_real:
        return False
    if not expected_real.startswith(mp_real.rstrip("/") + "/"):
        return False
    if os.path.basename(expected_real) != "slot%d" % int(source_slot):
        return False
    if os.path.lexists(base) and (not os.path.isdir(base) or os.path.islink(base)):
        return False
    if os.path.lexists(expected) and os.path.islink(expected):
        return False
    return True


def validate_internal_backup_state(state, mountpoint=None):
    if not isinstance(state, dict):
        return None
    if state.get("backup_mode") != "internal" or not state.get("verified"):
        return None
    try:
        source = int(state.get("source_slot"))
    except Exception:
        return None

    mp = mountpoint or ensure_full_mount(False)
    if not mp:
        return None
    info = compatible_startup_slots().get(source)
    if not info:
        return None

    backup_dir = internal_backup_dir(source, mp)
    if not internal_backup_path_is_safe(backup_dir, source, mp):
        return None
    if not os.path.isdir(backup_dir) or os.path.islink(backup_dir):
        return None

    meta_path = os.path.join(backup_dir, INTERNAL_BACKUP_META)
    disk = read_json_file(meta_path)
    if disk.get("backup_mode") != "internal" or not disk.get("verified"):
        return None
    try:
        if int(disk.get("source_slot")) != source:
            return None
    except Exception:
        return None

    recorded_root = os.path.realpath(disk.get("root_device") or "")
    live_root = os.path.realpath(root_device() or "")
    if not recorded_root or recorded_root != live_root:
        return None

    rootfs = os.path.join(backup_dir, "rootfs")
    if os.path.islink(rootfs) or not slot_root_tree_valid(rootfs):
        return None

    image_hash = disk.get("image_version_sha256", "")
    if not image_hash or sha256_prefix(os.path.join(rootfs, "etc", "image-version")) != image_hash:
        return None

    kernel_hash = disk.get("kernel_sha256", "")
    if not kernel_hash:
        return None
    if is_gbtrio4k():
        kernel_file = os.path.join(backup_dir, "kernel.img")
        if os.path.islink(kernel_file) or not os.path.isfile(kernel_file):
            return None
        if sha256_prefix(kernel_file) != kernel_hash:
            return None
        try:
            expected_size = int(disk.get("kernel_size", 0))
        except Exception:
            expected_size = 0
        if expected_size > 0:
            try:
                if os.path.getsize(kernel_file) != expected_size:
                    return None
            except Exception:
                return None
    else:
        zimage = os.path.join(rootfs, "zImage")
        if not os.path.isfile(zimage) or sha256_prefix(zimage) != kernel_hash:
            return None

    result = dict(disk)
    result["_backup_dir"] = backup_dir
    result["_rootfs"] = rootfs
    return result


def discover_internal_backups(mountpoint=None):
    mp = mountpoint or ensure_full_mount(False)
    if not mp:
        return []
    base = internal_backup_base(mp)
    if not os.path.isdir(base) or os.path.islink(base):
        return []
    result = []
    for entry in sorted(glob.glob(os.path.join(base, "slot*"))):
        if os.path.islink(entry) or not os.path.isdir(entry):
            continue
        meta = read_json_file(os.path.join(entry, INTERNAL_BACKUP_META))
        valid = validate_internal_backup_state(meta, mp)
        if valid:
            result.append(valid)
    result.sort(key=lambda x: str(x.get("created_sort", "")), reverse=True)
    return result


def _clean_hw_value(value):
    value = str(value or "").strip()
    if not value or value.lower() in ("unknown", "none", "n/a", "null"):
        return ""
    return value


def detect_box_identity():
    """Return a user-facing (brand, model) without assuming a specific receiver vendor."""
    brand = ""
    model_candidates = []

    def add_model(value):
        value = _clean_hw_value(value)
        if value and value not in model_candidates:
            model_candidates.append(value)

    # OpenATV/OE-A SystemInfo is preferred when available. Some images return
    # only the vendor name as displaymodel; keep collecting fallbacks instead
    # of displaying e.g. "GigaBlue GigaBlue".
    try:
        from Components.SystemInfo import BoxInfo
        for key in ("displaybrand", "brand", "manufacturer"):
            value = _clean_hw_value(BoxInfo.getItem(key))
            if value:
                brand = value
                break
        for key in ("displaymodel", "model", "machinebuild", "boxtype", "machine"):
            add_model(BoxInfo.getItem(key))
    except Exception:
        pass

    # Cross-image fallbacks.
    if not brand:
        for path in ("/proc/stb/info/brand", "/proc/stb/info/manufacturer"):
            value = _clean_hw_value(read_text(path))
            if value:
                brand = value
                break
    for path in ("/proc/stb/info/model", "/proc/stb/info/boxtype", "/proc/stb/info/machinebuild"):
        add_model(read_text(path))

    info = image_info()
    for key in ("displaymodel", "model", "box_type", "machinebuild", "machine"):
        add_model(info.get(key))

    # Normalize common brand spelling before filtering model candidates.
    b = brand.lower().replace(" ", "")
    if b in ("vuplus", "vu+"):
        brand = "VU+"
    elif b == "gigablue":
        brand = "GigaBlue"
    elif b == "octagon":
        brand = "Octagon"

    def norm(value):
        return re.sub(r"[^a-z0-9+]", "", (value or "").lower())

    # Human-friendly names for common receiver families.
    aliases = {
        "vuduo4kse": ("VU+", "Duo 4K SE"),
        "vuduo4k": ("VU+", "Duo 4K"),
        "vuuno4kse": ("VU+", "Uno 4K SE"),
        "vuuno4k": ("VU+", "Uno 4K"),
        "vusolo4k": ("VU+", "Solo 4K"),
        "vuzero4k": ("VU+", "Zero 4K"),
        "sf8008": ("Octagon", "SF8008"),
        "sf8008m": ("Octagon", "SF8008 M"),
        "sf8008s": ("Octagon", "SF8008 S"),
        "sf8008t": ("Octagon", "SF8008 T"),
        "sf8008combo": ("Octagon", "SF8008 Combo"),
        "sf8008supreme": ("Octagon", "SF8008 Supreme"),
        "sf4008": ("Octagon", "SF4008"),
        "gbquad4k": ("GigaBlue", "UHD Quad 4K"),
        "gbquad4kpro": ("GigaBlue", "UHD Quad 4K Pro"),
        "gbue4k": ("GigaBlue", "UHD UE 4K"),
        "gbx34k": ("GigaBlue", "UHD X3 4K"),
        "gbtrio4k": ("GigaBlue", "UHD Trio 4K"),
        "gbtrio4kpro": ("GigaBlue", "UHD Trio 4K Pro"),
    }

    alias = None
    for candidate in model_candidates:
        key = norm(candidate)
        if key in aliases:
            alias = aliases[key]
            break
    if alias:
        brand, model = alias
        return brand, model

    # Pick the first candidate that is more informative than the vendor name.
    model = ""
    brand_norm = norm(brand)
    generic_values = {"receiver", "settopbox", "stb", "enigma2", brand_norm}
    for candidate in model_candidates:
        c = norm(candidate)
        if c and c not in generic_values:
            model = candidate.strip()
            break

    # Derive a conservative brand only from unmistakable model prefixes.
    low = norm(model or (model_candidates[0] if model_candidates else ""))
    if not brand:
        if low.startswith("vu"):
            brand = "VU+"
        elif low.startswith("sf"):
            brand = "Octagon"
        elif low.startswith("gb"):
            brand = "GigaBlue"
        else:
            brand = "Receiver"

    if not model:
        model = ""

    return brand, model

# r26: restore the classic VU+ Duo 4K SE hero artwork only on that box.
# Other receivers (GigaBlue/Octagon/etc.) keep the vendor-neutral r25 artwork.
_BOOT_BRAND, _BOOT_MODEL = detect_box_identity()
def _hw_norm(value):
    return re.sub(r"[^a-z0-9+]", "", (value or "").lower())

_USE_CLASSIC_VU_DUO4KSE = (
    _BOOT_BRAND == "VU+" and _hw_norm(_BOOT_MODEL) in ("duo4kse", "vuduo4kse")
)
_BACKGROUND_FILE = (
    "background_vu_duo4kse.png" if _USE_CLASSIC_VU_DUO4KSE else "background_generic.png"
)
_BACKGROUND_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/SafeUpdate2026/" + _BACKGROUND_FILE


def rotation_layout_supported():
    """True only for receiver layouts explicitly allowed to rotate backups in r33."""
    if _USE_CLASSIC_VU_DUO4KSE:
        return True
    if is_gbtrio4k():
        return True
    return False


def rotation_layout_name():
    if _USE_CLASSIC_VU_DUO4KSE:
        return "VU+ Duo 4K SE"
    if is_gbtrio4k():
        return "GigaBlue UHD Trio 4K"
    return "nicht freigegebenes Layout"

def package_on_hold(package):
    out = run_cmd(["opkg", "status", package])
    for line in out.splitlines():
        if line.startswith("Status:"):
            return " hold " in (" " + line + " ")
    return False


def holds_ok():
    return all(package_on_hold(p) for p in kernel_packages())


def ensure_kernel_holds():
    for package in kernel_packages():
        try:
            if subprocess.call(["opkg", "flag", "hold", package]) != 0:
                return False
        except Exception:
            return False
    return holds_ok()

def load_state():
    try:
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(data):
    try:
        with open(STATE_FILE, "w") as f:
            json.dump(data, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def shq(s):
    return "'" + str(s).replace("'", "'\"'\"'") + "'"


ROTATION_STATE_KEYS = (
    "rotation_enabled",
    "system_fingerprint",
    "rotation_last_check",
    "rotation_last_success",
    "rotation_last_error",
    "rotation_next_due",
    "rotation_post_update_hold_until",
)

_SAFEUPDATE_UI_OPEN = 0
_ROTATION_SERVICE = None


def _state_without_runtime_keys(state):
    if not isinstance(state, dict):
        return {}
    return dict((k, v) for k, v in state.items() if not str(k).startswith("_"))


def current_system_fingerprint():
    """Fingerprint image metadata + installed package versions, not user config."""
    h = hashlib.sha256()
    seen = False
    image = read_text("/etc/image-version")
    if image:
        h.update(image.encode("utf-8", "replace"))
        seen = True
    packages = run_cmd(["opkg", "list-installed"])
    if packages:
        lines = sorted(x.strip() for x in packages.splitlines() if x.strip())
        h.update(("\n".join(lines)).encode("utf-8", "replace"))
        seen = True
    return h.hexdigest() if seen else ""


def rotation_time_text(epoch):
    try:
        epoch = int(epoch)
    except Exception:
        return "nicht geplant"
    left = epoch - int(time.time())
    if left <= 0:
        return "fällig"
    hours = left // 3600
    minutes = (left % 3600) // 60
    return "in %d h %02d min" % (hours, minutes)


def rotation_status_text(state):
    if not isinstance(state, dict) or not state.get("verified"):
        return "Status: Noch kein verifiziertes Backup."
    if not rotation_layout_supported():
        return "Status: Backup verifiziert · Auto-Rotation NICHT VERFÜGBAR"
    if not state.get("rotation_enabled", False):
        return "Status: Backup verifiziert · Auto-Rotation AUS (Taste 8)"
    return "Status: Backup verifiziert · Auto 24h EIN · nächste Prüfung %s" % rotation_time_text(state.get("rotation_next_due", 0))


def _rotation_seed(state, enabled=True, fingerprint=None, now=None):
    result = dict(state or {})
    now = int(time.time()) if now is None else int(now)
    fp = fingerprint if fingerprint is not None else current_system_fingerprint()
    enabled = bool(enabled and rotation_layout_supported())
    result["rotation_enabled"] = enabled
    result["system_fingerprint"] = fp or ""
    result["rotation_last_check"] = now
    result["rotation_last_success"] = now
    result["rotation_last_error"] = ""
    result["rotation_next_due"] = now + ROTATION_INTERVAL if enabled else 0
    result.pop("rotation_post_update_hold_until", None)
    return result


def _merge_rotation_fields(base, source):
    result = dict(base or {})
    for key in ROTATION_STATE_KEYS:
        if key in source:
            result[key] = source[key]
    return result


def persist_rotation_state(state):
    """Persist runtime state and mirror rotation fields into internal-backup metadata."""
    clean = _state_without_runtime_keys(state)
    ok = save_state(clean)
    if clean.get("backup_mode") != "internal" or not clean.get("verified"):
        return ok
    try:
        source = int(clean.get("source_slot"))
    except Exception:
        return ok
    mp = ensure_full_mount(False)
    if not mp:
        return ok
    backup_dir = internal_backup_dir(source, mp)
    if not internal_backup_path_is_safe(backup_dir, source, mp):
        return ok
    meta_path = os.path.join(backup_dir, INTERNAL_BACKUP_META)
    disk = read_json_file(meta_path)
    if disk.get("backup_mode") != "internal" or not disk.get("verified"):
        return ok
    try:
        if int(disk.get("source_slot")) != source:
            return ok
    except Exception:
        return ok
    merged = _merge_rotation_fields(disk, clean)
    save_json_file(meta_path, merged)
    return ok


def physically_verified_rotation_state(state=None):
    state = load_state() if state is None else state
    if not isinstance(state, dict) or not state.get("verified"):
        return None
    try:
        source = int(state.get("source_slot"))
    except Exception:
        return None
    if source != current_slot():
        return None
    mode = state.get("backup_mode", "slot")
    if mode == "internal":
        checked = validate_internal_backup_state(state)
        if checked is None:
            return None
        return _merge_rotation_fields(checked, state)
    if mode != "slot":
        return None
    try:
        target = int(state.get("target_slot"))
    except Exception:
        return None
    if target == source:
        return None
    info = compatible_startup_slots().get(target)
    mp = ensure_full_mount(False)
    if not info or not mp:
        return None
    dst = os.path.join(mp, info["rootsubdir"])
    if not slot_backup_valid(target, dst, state.get("kernel_sha256", "")):
        return None
    return dict(state)


def ensure_rotation_state(state):
    if state is None:
        return None
    result = dict(state)
    if not rotation_layout_supported():
        changed = (
            result.get("rotation_enabled") is not False or
            int(result.get("rotation_next_due") or 0) != 0 or
            result.get("rotation_last_error") != "Auto-Rotation sicher deaktiviert: Box-/Slot-Layout nicht freigegeben."
        )
        result["rotation_enabled"] = False
        result["rotation_next_due"] = 0
        result["rotation_last_error"] = "Auto-Rotation sicher deaktiviert: Box-/Slot-Layout nicht freigegeben."
        result.pop("rotation_post_update_hold_until", None)
        if changed:
            persist_rotation_state(result)
        return result
    if "rotation_enabled" not in result:
        result = _rotation_seed(result, True)
        persist_rotation_state(result)
    elif result.get("rotation_enabled") and not result.get("rotation_next_due"):
        result["rotation_next_due"] = int(time.time()) + ROTATION_INTERVAL
        if not result.get("system_fingerprint"):
            result["system_fingerprint"] = current_system_fingerprint()
        persist_rotation_state(result)
    return result


def rotation_temp_path_safe(temp_path, canonical, suffix):
    if not temp_path or not canonical or not temp_path.endswith(suffix):
        return False
    if os.path.realpath(os.path.dirname(temp_path)) != os.path.realpath(os.path.dirname(canonical)):
        return False
    return os.path.realpath(temp_path) != os.path.realpath(canonical)


def _remove_safe_rotation_tree(path, canonical, suffix):
    if not rotation_temp_path_safe(path, canonical, suffix):
        return False
    if not os.path.lexists(path):
        return True
    if os.path.islink(path) or not os.path.isdir(path):
        return False
    return subprocess.call(["rm", "-rf", "--", path]) == 0 and not os.path.lexists(path)


def post_update_rotation_delay():
    state = physically_verified_rotation_state()
    if state is None or not state.get("rotation_enabled", False):
        return
    now = int(time.time())
    state["rotation_last_check"] = now
    state["rotation_last_error"] = ""
    state["rotation_post_update_hold_until"] = now + ROTATION_INTERVAL
    state["rotation_next_due"] = now + ROTATION_INTERVAL
    # Intentionally keep the OLD fingerprint. In 24h it will differ from the
    # updated system and rotate only then, preserving the pre-update rollback.
    persist_rotation_state(state)


class SafeUpdateRotationService(object):
    def __init__(self, session=None):
        self.session = session
        self.timer = eTimer()
        self.container = None
        self.busy = False
        self.pending = None
        self.ui = None
        try:
            self.timer.callback.append(self._timer_tick)
        except Exception:
            try:
                self.timer.timeout.connect(self._timer_tick)
            except Exception:
                pass
        if rotation_layout_supported():
            try:
                self.timer.start(5 * 60 * 1000, True)
            except Exception:
                pass

    def _schedule_periodic(self):
        if not rotation_layout_supported():
            return
        try:
            self.timer.start(ROTATION_TICK_MS, False)
        except Exception:
            pass

    def _timer_tick(self):
        try:
            self.check(False, None)
        finally:
            self._schedule_periodic()

    def _emit(self, text):
        line = "[AUTO-ROTATION] %s" % str(text)
        try:
            with open(LOG_FILE, "a") as f:
                f.write(line + "\n")
        except Exception:
            pass
        try:
            print(line)
        except Exception:
            pass
        if self.ui is not None:
            try:
                self.ui.append_log("> AUTO: " + str(text))
            except Exception:
                pass

    def _save_retry(self, state, reason):
        state = dict(state or {})
        now = int(time.time())
        state["rotation_last_check"] = now
        state["rotation_last_error"] = str(reason)
        state["rotation_next_due"] = now + ROTATION_RETRY_INTERVAL
        persist_rotation_state(state)

    def check(self, force=False, ui=None):
        global _SAFEUPDATE_UI_OPEN
        if self.busy:
            return False
        if _SAFEUPDATE_UI_OPEN and ui is None:
            return False
        if not rotation_layout_supported():
            if force:
                self._emit("Rotation blockiert: Box-/Slot-Layout ist für r33 nicht freigegeben.")
            return False

        state = physically_verified_rotation_state()
        if state is None:
            return False
        state = ensure_rotation_state(state)
        if state is None:
            return False
        if not force and not state.get("rotation_enabled", False):
            return False

        now = int(time.time())
        due = int(state.get("rotation_next_due") or 0)
        if not force and due and now < due:
            return False

        fp = current_system_fingerprint()
        if not fp:
            self._save_retry(state, "System-Fingerprint konnte nicht erstellt werden.")
            self._emit("Fingerprint fehlgeschlagen; neuer Versuch in 1 Stunde.")
            return False

        previous_fp = state.get("system_fingerprint", "")
        if not force and previous_fp and previous_fp == fp:
            state["rotation_last_check"] = now
            state["rotation_last_error"] = ""
            state["rotation_next_due"] = now + ROTATION_INTERVAL
            state.pop("rotation_post_update_hold_until", None)
            persist_rotation_state(state)
            self._emit("24h-Prüfung: System unverändert – kein neues Vollbackup.")
            return True

        if not force and not previous_fp:
            state["system_fingerprint"] = fp
            state["rotation_last_check"] = now
            state["rotation_last_error"] = ""
            state["rotation_next_due"] = now + ROTATION_INTERVAL
            persist_rotation_state(state)
            self._emit("24h-Basiswert gesetzt; erste Rotation frühestens in 24h.")
            return True

        if not kexec_ok():
            self._save_retry(state, "Multiboot-/KEXEC-Schutz nicht verifiziert.")
            self._emit("Rotation blockiert: Multiboot-/KEXEC-Schutz nicht verifiziert.")
            return False

        mode = state.get("backup_mode", "slot")
        if mode == "internal":
            return self._start_internal_rotation(state, fp, ui)
        if mode == "slot":
            return self._start_slot_rotation(state, fp, ui)
        self._save_retry(state, "Unbekannter Backup-Modus.")
        return False

    def _ui_start(self, ui, title, status):
        self.ui = ui
        if ui is not None:
            try:
                ui.busy = True
                ui.paint_update_state()
                ui.set_backup_progress(10, title, status)
            except Exception:
                pass

    def _ui_finish(self):
        ui = self.ui
        if ui is not None:
            try:
                ui.busy = False
                ui.paint_update_state()
            except Exception:
                pass
        return ui

    def _start_slot_rotation(self, state, fingerprint, ui):
        try:
            source = int(state.get("source_slot"))
            target = int(state.get("target_slot"))
        except Exception:
            self._save_retry(state, "Slot-Zuordnung ungültig.")
            return False
        if source != current_slot() or target == source:
            self._save_retry(state, "Slot-Zuordnung nicht sicher.")
            return False

        info = compatible_startup_slots().get(target)
        mp = ensure_full_mount(True)
        if not info or not mp:
            self._save_retry(state, "Backup-Slot/Dateisystem nicht sicher verfügbar.")
            return False
        src = active_source_path(mp)
        dst = os.path.join(mp, info["rootsubdir"])
        if not src or not slot_root_tree_valid(src):
            self._save_retry(state, "Aktiver Quellslot nicht verifizierbar.")
            return False
        if not slot_backup_valid(target, dst, state.get("kernel_sha256", "")):
            self._save_retry(state, "Bisheriges Sicherheitsbackup nicht mehr verifizierbar.")
            return False

        newdir = dst + ROTATION_NEW_SUFFIX
        olddir = dst + ROTATION_OLD_SUFFIX
        newkernel = dst + ROTATION_NEW_KERNEL_SUFFIX
        oldkernel = dst + ROTATION_OLD_KERNEL_SUFFIX
        temp_paths = ((newdir, ROTATION_NEW_SUFFIX), (olddir, ROTATION_OLD_SUFFIX))
        if is_gbtrio4k():
            temp_paths += ((newkernel, ROTATION_NEW_KERNEL_SUFFIX), (oldkernel, ROTATION_OLD_KERNEL_SUFFIX))
        for temp_path, suffix in temp_paths:
            if not rotation_temp_path_safe(temp_path, dst, suffix) or os.path.lexists(temp_path):
                self._save_retry(state, "Temporärer Rotationsrest vorhanden: %s" % os.path.basename(temp_path))
                self._emit("Rotation blockiert: temporärer Rest vorhanden; nichts wird automatisch gelöscht.")
                return False

        source_bytes = tree_size_bytes(src)
        free_bytes = filesystem_free_bytes(mp)
        reserve = 128 * 1024 * 1024
        extra = 0
        src_kernel = ""
        dst_kernel = ""
        if is_gbtrio4k():
            src_kernel = active_kernel_device()
            dst_kernel = kernel_device_for_slot(target)
            if (not gigablue_kernel_layout_ok() or not src_kernel or not dst_kernel or
                    src_kernel == dst_kernel or dst_kernel != expected_kernel_device(target)):
                self._save_retry(state, "GigaBlue Kernel-Slot nicht sicher verifizierbar.")
                return False
            kernel_bytes = block_device_size(src_kernel)
            if kernel_bytes <= 0:
                self._save_retry(state, "Kernelgröße nicht bestimmbar.")
                return False
            extra = kernel_bytes * 2
        if source_bytes <= 0 or free_bytes < source_bytes + extra + reserve:
            self._save_retry(state, "Nicht genug freier Speicher für sichere Doppelkopie.")
            self._emit("Rotation verschoben: nicht genug Platz für neues Backup + bisheriges Backup.")
            return False

        if is_gbtrio4k():
            expected_old_hash = state.get("kernel_sha256", "")
            script = r'''
set -e
SRC={src}
DST={dst}
NEW={newdir}
OLD={olddir}
SRC_KERNEL={src_kernel}
DST_KERNEL={dst_kernel}
NEW_KERNEL={newkernel}
OLD_KERNEL={oldkernel}
EXPECTED_OLD_HASH={expected_old_hash}

restore_previous() {{
    rc="$1"
    if [ "$rc" -ne 0 ]; then
        echo 'Rotation fehlgeschlagen – stelle vorheriges Backup wieder her.'
        if [ -d "$OLD" ]; then
            if [ -e "$DST" ]; then rm -rf "$DST"; fi
            mv "$OLD" "$DST" 2>/dev/null || true
        fi
        if [ -f "$OLD_KERNEL" ]; then
            dd if="$OLD_KERNEL" of="$DST_KERNEL" bs=1048576 conv=fsync 2>/dev/null || true
        fi
        if [ -e "$NEW" ]; then rm -rf "$NEW"; fi
        rm -f "$NEW_KERNEL"
        sync
    fi
    exit "$rc"
}}
trap 'rc=$?; restore_previous "$rc"' EXIT

test -d "$SRC"
test -f "$SRC/etc/image-version"
test -e "$SRC/sbin/init"
test -f "$SRC/usr/bin/enigma2"
test -d "$DST"
test -f "$DST/etc/image-version"
test -b "$SRC_KERNEL"
test -b "$DST_KERNEL"
test ! -e "$NEW"
test ! -e "$OLD"
test ! -e "$NEW_KERNEL"
test ! -e "$OLD_KERNEL"

echo 'Erstelle neue Sicherung neben dem bisherigen Backup ...'
mkdir "$NEW"
cp -a "$SRC"/. "$NEW"/
sync
test -f "$NEW/etc/image-version"
test -e "$NEW/sbin/init"
test -f "$NEW/usr/bin/enigma2"

echo 'Sichere bisherigen Backup-Kernel temporär ...'
dd if="$DST_KERNEL" of="$OLD_KERNEL" bs=1048576 conv=fsync 2>/dev/null
OLD_HASH=$(sha256sum "$OLD_KERNEL" | awk '{{print $1}}')
DST_OLD_HASH=$(sha256sum "$DST_KERNEL" | awk '{{print $1}}')
[ -n "$OLD_HASH" ]
[ "$OLD_HASH" = "$DST_OLD_HASH" ] || exit 41
if [ -n "$EXPECTED_OLD_HASH" ]; then [ "$OLD_HASH" = "$EXPECTED_OLD_HASH" ] || exit 42; fi

echo 'Kopiere neuen Kernel zunächst in Sicherheitsdatei ...'
dd if="$SRC_KERNEL" of="$NEW_KERNEL" bs=1048576 conv=fsync 2>/dev/null
SRC_HASH=$(sha256sum "$SRC_KERNEL" | awk '{{print $1}}')
NEW_HASH=$(sha256sum "$NEW_KERNEL" | awk '{{print $1}}')
[ -n "$SRC_HASH" ]
[ "$SRC_HASH" = "$NEW_HASH" ] || exit 43

echo 'Neue Sicherung vollständig kopiert und Kernel verifiziert.'
mv "$DST" "$OLD"
mv "$NEW" "$DST"
sync

echo 'Aktiviere neuen Backup-Kernel ...'
dd if="$NEW_KERNEL" of="$DST_KERNEL" bs=1048576 conv=fsync 2>/dev/null
sync
DST_HASH=$(sha256sum "$DST_KERNEL" | awk '{{print $1}}')
[ "$SRC_HASH" = "$DST_HASH" ] || exit 44
test -f "$DST/etc/image-version"
test -e "$DST/sbin/init"
test -f "$DST/usr/bin/enigma2"

echo 'Neues Sicherheitsbackup final verifiziert.'
rm -rf "$OLD"
rm -f "$OLD_KERNEL" "$NEW_KERNEL"
sync
trap - EXIT
echo 'ROTATION_VERIFIED'
'''.format(src=shq(src), dst=shq(dst), newdir=shq(newdir), olddir=shq(olddir),
           src_kernel=shq(src_kernel), dst_kernel=shq(dst_kernel), newkernel=shq(newkernel),
           oldkernel=shq(oldkernel), expected_old_hash=shq(expected_old_hash))
        else:
            script = r'''
set -e
SRC={src}
DST={dst}
NEW={newdir}
OLD={olddir}

restore_previous() {{
    rc="$1"
    if [ "$rc" -ne 0 ]; then
        echo 'Rotation fehlgeschlagen – stelle vorheriges Backup wieder her.'
        if [ -d "$OLD" ]; then
            if [ -e "$DST" ]; then rm -rf "$DST"; fi
            mv "$OLD" "$DST" 2>/dev/null || true
        fi
        if [ -e "$NEW" ]; then rm -rf "$NEW"; fi
        sync
    fi
    exit "$rc"
}}
trap 'rc=$?; restore_previous "$rc"' EXIT

test -d "$SRC"
test -f "$SRC/etc/image-version"
test -f "$SRC/zImage"
test -d "$DST"
test -f "$DST/etc/image-version"
test -f "$DST/zImage"
test ! -e "$NEW"
test ! -e "$OLD"

echo 'Erstelle neue Sicherung neben dem bisherigen Backup ...'
mkdir "$NEW"
cp -a "$SRC"/. "$NEW"/
sync
test -f "$NEW/etc/image-version"
test -f "$NEW/zImage"
SRC_HASH=$(sha256sum "$SRC/zImage" | awk '{{print $1}}')
NEW_HASH=$(sha256sum "$NEW/zImage" | awk '{{print $1}}')
[ -n "$SRC_HASH" ]
[ "$SRC_HASH" = "$NEW_HASH" ] || exit 31
echo 'Neue Sicherung vollständig kopiert und Kernel verifiziert.'

mv "$DST" "$OLD"
mv "$NEW" "$DST"
sync
test -f "$DST/etc/image-version"
test -f "$DST/zImage"
DST_HASH=$(sha256sum "$DST/zImage" | awk '{{print $1}}')
[ "$SRC_HASH" = "$DST_HASH" ] || exit 32
echo 'Neues Sicherheitsbackup final verifiziert.'

rm -rf "$OLD"
sync
trap - EXIT
echo 'ROTATION_VERIFIED'
'''.format(src=shq(src), dst=shq(dst), newdir=shq(newdir), olddir=shq(olddir))

        self.busy = True
        self.pending = {
            "mode": "slot",
            "state": dict(state),
            "source": source,
            "target": target,
            "dst": dst,
            "newdir": newdir,
            "olddir": olddir,
            "newkernel": newkernel if is_gbtrio4k() else "",
            "oldkernel": oldkernel if is_gbtrio4k() else "",
            "fingerprint": fingerprint,
        }
        self._ui_start(ui, "Auto-Rotation – neues Backup", "Status: Altes Backup bleibt erhalten, bis das neue verifiziert ist ...")
        self._emit("Rotation startet: Slot %d → Sicherheits-Slot %d." % (source, target))
        self.container = eConsoleAppContainer()
        try:
            self.container.dataAvail.append(self._data)
            self.container.appClosed.append(self._closed)
        except Exception:
            self.container.dataAvail.connect(self._data)
            self.container.appClosed.connect(self._closed)
        self.container.execute("/bin/sh -c %s" % shq(script))
        return True

    def _start_internal_rotation(self, state, fingerprint, ui):
        checked = validate_internal_backup_state(state)
        if checked is None:
            self._save_retry(state, "Internes Backup nicht mehr verifizierbar.")
            return False
        source = int(checked.get("source_slot"))
        if source != current_slot():
            self._save_retry(state, "Gesicherter Quellslot ist nicht aktiv.")
            return False
        mp = ensure_full_mount(True)
        if not mp:
            self._save_retry(state, "Internes Multiboot-Dateisystem nicht schreibbar.")
            return False
        src = active_source_path(mp)
        dst = internal_backup_dir(source, mp)
        if not src or not slot_root_tree_valid(src) or not internal_backup_path_is_safe(dst, source, mp):
            self._save_retry(state, "Quelle oder internes Backup-Ziel nicht sicher verifizierbar.")
            return False
        checked = validate_internal_backup_state(state, mp)
        if checked is None:
            self._save_retry(state, "Internes Backup nicht mehr verifizierbar.")
            return False

        newdir = dst + ROTATION_NEW_SUFFIX
        olddir = dst + ROTATION_OLD_SUFFIX
        for temp_path, suffix in ((newdir, ROTATION_NEW_SUFFIX), (olddir, ROTATION_OLD_SUFFIX)):
            if not rotation_temp_path_safe(temp_path, dst, suffix) or os.path.lexists(temp_path):
                self._save_retry(state, "Temporärer interner Rotationsrest vorhanden: %s" % os.path.basename(temp_path))
                self._emit("Interne Rotation blockiert: temporärer Rest vorhanden; bestehendes Backup bleibt erhalten.")
                return False

        source_bytes = tree_size_bytes(src)
        kernel_bytes = block_device_size(active_kernel_device()) if is_gbtrio4k() else 0
        free_bytes = filesystem_free_bytes(mp)
        reserve = 128 * 1024 * 1024
        needed = source_bytes + kernel_bytes + reserve
        if source_bytes <= 0 or free_bytes < needed:
            self._save_retry(state, "Nicht genug freier Speicher für sichere interne Doppelkopie.")
            self._emit("Interne Rotation verschoben: nicht genug freier eMMC-Speicher.")
            return False

        now = int(time.time())
        enabled = bool(state.get("rotation_enabled", True))
        next_due = now + ROTATION_INTERVAL if enabled else 0
        created = datetime.now().strftime("%d.%m.%Y %H:%M")
        created_sort = datetime.now().strftime("%Y%m%d%H%M%S")
        build = image_info().get("build", "")
        rootdev = root_device()
        meta_py = (
            'import json,os,sys; '
            'p=sys.argv[1]; d={'
            '"backup_mode":"internal","source_slot":int(sys.argv[2]),"created":sys.argv[3],'
            '"created_sort":sys.argv[4],"verified":True,"build":sys.argv[5],"root_device":sys.argv[6],'
            '"backup_rel":sys.argv[7],"kernel_sha256":sys.argv[8],"kernel_size":int(sys.argv[9]),'
            '"image_version_sha256":sys.argv[10],"rotation_enabled":(sys.argv[11]=="1"),'
            '"system_fingerprint":sys.argv[12],"rotation_last_check":int(sys.argv[13]),'
            '"rotation_last_success":int(sys.argv[13]),"rotation_last_error":"",'
            '"rotation_next_due":int(sys.argv[14])}; '
            'ks=sys.argv[15]; d.update({"kernel_source_device":ks} if ks else {}); '
            't=p+".tmp"; f=open(t,"w"); json.dump(d,f,indent=2,sort_keys=True); f.flush(); os.fsync(f.fileno()); f.close(); os.rename(t,p)'
        )
        src_kernel = active_kernel_device() if is_gbtrio4k() else ""
        kernel_size = block_device_size(src_kernel) if src_kernel else 0
        if is_gbtrio4k() and (not gigablue_kernel_layout_ok() or not src_kernel or kernel_size <= 0):
            self._save_retry(state, "GigaBlue Kernelquelle nicht sicher verifizierbar.")
            return False

        if is_gbtrio4k():
            kernel_copy = r'''
echo 'Kopiere Kernel in neues internes Sicherheitsbackup ...'
dd if="$SRC_KERNEL" of="$NEW/kernel.img" bs=1048576 conv=fsync 2>/dev/null
sync
KERNEL_HASH=$(sha256sum "$NEW/kernel.img" | awk '{{print $1}}')
SRC_KERNEL_HASH=$(sha256sum "$SRC_KERNEL" | awk '{{print $1}}')
[ -n "$KERNEL_HASH" ]
[ "$KERNEL_HASH" = "$SRC_KERNEL_HASH" ] || exit 53
'''
        else:
            kernel_copy = r'''
KERNEL_HASH=$(sha256sum "$ROOTFS/zImage" | awk '{{print $1}}')
SRC_KERNEL_HASH=$(sha256sum "$SRC/zImage" | awk '{{print $1}}')
[ -n "$KERNEL_HASH" ]
[ "$KERNEL_HASH" = "$SRC_KERNEL_HASH" ] || exit 53
'''

        script = r'''
set -e
SRC={src}
DST={dst}
NEW={newdir}
OLD={olddir}
ROOTFS="$NEW/rootfs"
SRC_KERNEL={src_kernel}
SOURCE_SLOT={source_slot}
CREATED={created}
CREATED_SORT={created_sort}
BUILD={build}
ROOTDEV={rootdev}
BACKUP_REL={backup_rel}
ROT_ENABLED={rot_enabled}
FINGERPRINT={fingerprint}
ROT_NOW={rot_now}
ROT_NEXT={rot_next}
KERNEL_SIZE={kernel_size}
KERNEL_SOURCE={kernel_source}
META_PY={meta_py}

restore_previous() {{
    rc="$1"
    if [ "$rc" -ne 0 ]; then
        echo 'Interne Rotation fehlgeschlagen – stelle vorheriges Backup wieder her.'
        if [ -d "$OLD" ]; then
            if [ -e "$DST" ]; then rm -rf "$DST"; fi
            mv "$OLD" "$DST" 2>/dev/null || true
        fi
        if [ -e "$NEW" ]; then rm -rf "$NEW"; fi
        sync
    fi
    exit "$rc"
}}
trap 'rc=$?; restore_previous "$rc"' EXIT

test -d "$SRC"
test -f "$SRC/etc/image-version"
test -d "$DST"
test -f "$DST/{meta_name}"
test ! -e "$NEW"
test ! -e "$OLD"

echo 'Erstelle neues internes Backup neben dem bisherigen Backup ...'
mkdir "$NEW"
mkdir "$ROOTFS"
cp -a "$SRC"/. "$ROOTFS"/
sync
test -f "$ROOTFS/etc/image-version"
test -e "$ROOTFS/sbin/init"
test -f "$ROOTFS/usr/bin/enigma2"
{kernel_copy}
IMAGE_HASH=$(sha256sum "$ROOTFS/etc/image-version" | awk '{{print $1}}')
[ -n "$IMAGE_HASH" ]
python3 -c "$META_PY" "$NEW/{meta_name}" "$SOURCE_SLOT" "$CREATED" "$CREATED_SORT" "$BUILD" "$ROOTDEV" "$BACKUP_REL" "$KERNEL_HASH" "$KERNEL_SIZE" "$IMAGE_HASH" "$ROT_ENABLED" "$FINGERPRINT" "$ROT_NOW" "$ROT_NEXT" "$KERNEL_SOURCE"
test -f "$NEW/{meta_name}"
echo 'Neue interne Sicherung vollständig vorbereitet und verifiziert.'

mv "$DST" "$OLD"
mv "$NEW" "$DST"
sync
test -f "$DST/{meta_name}"
test -f "$DST/rootfs/etc/image-version"
DST_IMAGE_HASH=$(sha256sum "$DST/rootfs/etc/image-version" | awk '{{print $1}}')
[ "$IMAGE_HASH" = "$DST_IMAGE_HASH" ] || exit 54
{post_kernel_check}
echo 'Neues internes Sicherheitsbackup final verifiziert.'
# OLD bleibt bis zur Python-Abschlussvalidierung erhalten.
trap - EXIT
echo 'ROTATION_VERIFIED'
'''.format(
            src=shq(src), dst=shq(dst), newdir=shq(newdir), olddir=shq(olddir),
            src_kernel=shq(src_kernel), source_slot=shq(source), created=shq(created), created_sort=shq(created_sort),
            build=shq(build), rootdev=shq(rootdev), backup_rel=shq("%s/slot%d" % (INTERNAL_BACKUP_DIRNAME, source)),
            rot_enabled=shq("1" if enabled else "0"), fingerprint=shq(fingerprint), rot_now=shq(now),
            rot_next=shq(next_due), kernel_size=shq(kernel_size), kernel_source=shq(src_kernel), meta_py=shq(meta_py),
            meta_name=INTERNAL_BACKUP_META, kernel_copy=kernel_copy,
            post_kernel_check=(
                'DST_KERNEL_HASH=$(sha256sum "$DST/kernel.img" | awk \'{print $1}\'); [ "$KERNEL_HASH" = "$DST_KERNEL_HASH" ] || exit 55'
                if is_gbtrio4k() else
                'DST_KERNEL_HASH=$(sha256sum "$DST/rootfs/zImage" | awk \'{print $1}\'); [ "$KERNEL_HASH" = "$DST_KERNEL_HASH" ] || exit 55'
            )
        )

        self.busy = True
        self.pending = {
            "mode": "internal",
            "state": dict(state),
            "source": source,
            "dst": dst,
            "newdir": newdir,
            "olddir": olddir,
            "fingerprint": fingerprint,
        }
        self._ui_start(ui, "Auto-Rotation – internes eMMC", "Status: Bisheriges Backup bleibt erhalten, bis die neue Kopie verifiziert ist ...")
        self._emit("Interne Rotation startet: Slot %d → /%s/slot%d." % (source, INTERNAL_BACKUP_DIRNAME, source))
        self.container = eConsoleAppContainer()
        try:
            self.container.dataAvail.append(self._data)
            self.container.appClosed.append(self._closed)
        except Exception:
            self.container.dataAvail.connect(self._data)
            self.container.appClosed.connect(self._closed)
        self.container.execute("/bin/sh -c %s" % shq(script))
        return True

    def _data(self, data):
        try:
            txt = data.decode("utf-8", "replace")
        except Exception:
            txt = str(data)
        for line in txt.splitlines():
            self._emit(line[:160])
            ui = self.ui
            if ui is not None:
                low = line.lower()
                try:
                    if "erstelle neue" in low:
                        ui.set_backup_progress(15, "Auto-Rotation – Kopieren", "Status: Neues Backup wird erstellt ...")
                    elif "vollständig" in low and "verifiziert" in low:
                        ui.set_backup_progress(80, "Auto-Rotation – Verifizieren", "Status: Neue Sicherung vor Austausch verifiziert ...")
                    elif "final verifiziert" in low:
                        ui.set_backup_progress(96, "Auto-Rotation – Abschluss", "Status: Neues Backup final verifiziert ...")
                    elif "rotation_verified" in low:
                        ui.set_backup_progress(99, "Auto-Rotation – Abschluss", "Status: Abschlussprüfung ...")
                except Exception:
                    pass

    def _closed(self, rc):
        pending = self.pending
        self.pending = None
        self.busy = False
        ui = self._ui_finish()
        self.ui = None
        if not pending:
            return
        if pending.get("mode") == "internal":
            self._closed_internal(rc, pending, ui)
        else:
            self._closed_slot(rc, pending, ui)

    def _closed_slot(self, rc, pending, ui):
        state = pending["state"]
        target = pending["target"]
        dst = pending["dst"]
        now = int(time.time())
        verified = (
            rc == 0 and
            not os.path.lexists(pending["newdir"]) and
            not os.path.lexists(pending["olddir"]) and
            (not pending.get("newkernel") or not os.path.lexists(pending["newkernel"])) and
            (not pending.get("oldkernel") or not os.path.lexists(pending["oldkernel"])) and
            slot_backup_valid(target, dst)
        )
        if verified:
            enabled = bool(state.get("rotation_enabled", True))
            created = datetime.now().strftime("%d.%m.%Y %H:%M")
            new_state = dict(state)
            new_state.update({
                "backup_mode": "slot",
                "source_slot": pending["source"],
                "target_slot": target,
                "created": created,
                "created_sort": datetime.now().strftime("%Y%m%d%H%M%S"),
                "verified": True,
                "build": image_info().get("build", ""),
            })
            new_state = _rotation_seed(new_state, enabled, pending["fingerprint"], now)
            if is_gbtrio4k():
                new_state["kernel_device"] = kernel_device_for_slot(target)
                new_state["kernel_sha256"] = sha256_prefix(new_state["kernel_device"])
            save_state(new_state)
            self._emit("Rotation erfolgreich. Vorheriges Backup erst NACH Verifikation entfernt.")
            if ui is not None:
                ui.backup_verified = True
                ui.verified_backup_slot = target
                ui.verified_backup_mode = "slot"
                ui.set_backup_progress(100, "Auto-Rotation – Fertig", rotation_status_text(new_state))
                ui["targetSlot"].setText("Slot %d – VERIFIZIERT ✓" % target)
                ui.load_rollback()
                ui.paint_update_state()
            return

        old_valid = slot_backup_valid(target, dst, state.get("kernel_sha256", ""))
        state["rotation_last_check"] = now
        state["rotation_last_error"] = "Rotation RC=%s" % rc
        state["rotation_next_due"] = now + ROTATION_RETRY_INTERVAL
        if not old_valid:
            state["verified"] = False
        save_state(_state_without_runtime_keys(state))
        self._emit("Rotation FEHLGESCHLAGEN (RC=%s). Altes Backup gültig: %s" % (rc, "JA" if old_valid else "NEIN"))
        if ui is not None:
            ui.backup_verified = bool(old_valid)
            ui.load_rollback()
            ui.paint_update_state()
            if old_valid:
                ui.set_backup_progress(100, "Auto-Rotation – abgebrochen", "Status: Neues Backup verworfen · bisheriges Backup weiterhin verifiziert.")
            else:
                ui.set_backup_progress(0, "Auto-Rotation – FEHLER", "Status: Backup nicht mehr sicher verifizierbar · Update gesperrt.")

    def _closed_internal(self, rc, pending, ui):
        state = pending["state"]
        dst = pending["dst"]
        olddir = pending["olddir"]
        now = int(time.time())
        checked = None
        if rc == 0:
            disk = read_json_file(os.path.join(dst, INTERNAL_BACKUP_META))
            checked = validate_internal_backup_state(disk)
        if checked is not None:
            cleanup_ok = _remove_safe_rotation_tree(olddir, dst, ROTATION_OLD_SUFFIX)
            persist_rotation_state(checked)
            self._emit("Interne Rotation erfolgreich. Vorheriges Backup erst NACH Verifikation entfernt%s." % ("" if cleanup_ok else "; alter Sicherungsrest konnte nicht entfernt werden"))
            if ui is not None:
                ui.backup_verified = True
                ui.verified_backup_slot = None
                ui.verified_backup_mode = "internal"
                ui.verified_backup_path = dst
                ui.recovery_state = checked
                ui.set_backup_progress(100, "Auto-Rotation – Fertig", rotation_status_text(checked))
                ui["targetSlot"].setText("Internes eMMC – VERIFIZIERT ✓")
                ui.load_rollback()
                ui.paint_update_state()
            return

        # If the shell already swapped directories but Python validation failed,
        # restore the old canonical backup before touching state.
        if os.path.isdir(olddir) and rotation_temp_path_safe(olddir, dst, ROTATION_OLD_SUFFIX):
            if os.path.lexists(dst) and not os.path.islink(dst):
                subprocess.call(["rm", "-rf", "--", dst])
            try:
                os.rename(olddir, dst)
            except Exception:
                pass
        old_checked = validate_internal_backup_state(state)
        if old_checked is not None:
            old_checked["rotation_last_check"] = now
            old_checked["rotation_last_error"] = "Interne Rotation RC=%s" % rc
            old_checked["rotation_next_due"] = now + ROTATION_RETRY_INTERVAL
            persist_rotation_state(old_checked)
        else:
            bad = dict(state)
            bad["verified"] = False
            bad["rotation_last_error"] = "Interne Rotation/Restore fehlgeschlagen"
            save_state(_state_without_runtime_keys(bad))
        self._emit("Interne Rotation FEHLGESCHLAGEN (RC=%s). Vorheriges Backup gültig: %s" % (rc, "JA" if old_checked is not None else "NEIN"))
        if ui is not None:
            ui.backup_verified = old_checked is not None
            ui.load_rollback()
            ui.paint_update_state()
            if old_checked is not None:
                ui.set_backup_progress(100, "Auto-Rotation – abgebrochen", "Status: Neues Backup verworfen · bisheriges internes Backup weiterhin verifiziert.")
            else:
                ui.set_backup_progress(0, "Auto-Rotation – FEHLER", "Status: Internes Backup nicht mehr sicher verifizierbar · Update gesperrt.")


def get_rotation_service(session=None):
    global _ROTATION_SERVICE
    if _ROTATION_SERVICE is None:
        _ROTATION_SERVICE = SafeUpdateRotationService(session)
    elif session is not None and _ROTATION_SERVICE.session is None:
        _ROTATION_SERVICE.session = session
    return _ROTATION_SERVICE


def rotation_sessionstart(reason, **kwargs):
    global _ROTATION_SERVICE
    if reason == 0:
        session = kwargs.get("session")
        if session is not None and rotation_layout_supported():
            get_rotation_service(session)
    elif reason == 1:
        try:
            if _ROTATION_SERVICE is not None:
                _ROTATION_SERVICE.timer.stop()
        except Exception:
            pass
        _ROTATION_SERVICE = None



class SafeUpdateScreen(Screen):
    skin = '''
    <screen name="SafeUpdateScreen" position="0,0" size="1920,1080" resolution="1920,1080" flags="wfNoBorder" backgroundColor="#000b14">
        <ePixmap zPosition="0" position="0,0" size="1920,1080"
                 pixmap="__BACKGROUND_PATH__"
                 scale="1" alphatest="on" />

        <!-- live time/date, aligned to approved preview -->
        <widget zPosition="20" name="clock" position="1755,9" size="126,44"
                font="Regular;34" halign="right" foregroundColor="#f4f8fb"
                backgroundColor="#061a2a" transparent="1" />
        <widget zPosition="20" name="date" position="1663,57" size="218,32"
                font="Regular;18" halign="right" foregroundColor="#d5e4f2"
                backgroundColor="#061a2a" transparent="1" />

        <!-- r25: one dynamic receiver identity in the header; hero artwork stays vendor-neutral -->
        <widget zPosition="35" name="boxHeader" position="1140,13" size="505,42"
                font="Regular;22" halign="center" valign="center" foregroundColor="#f4f8fb"
                backgroundColor="#061a2a" transparent="1" />

        <!-- current image -->
        <widget zPosition="20" name="currentInfo" position="161,188" size="597,39"
                font="Regular;27" foregroundColor="#f4f8fb"
                backgroundColor="#082640" transparent="1" />
        <widget zPosition="20" name="currentOK" position="942,188" size="83,39"
                font="Regular;25" halign="right" foregroundColor="#01f76f"
                backgroundColor="#082640" transparent="1" />

        <!-- safety statuses -->
        <widget zPosition="20" name="kexecOK" position="942,247" size="83,37"
                font="Regular;24" halign="right" foregroundColor="#01f76f"
                backgroundColor="#082136" transparent="1" />
        <widget zPosition="20" name="holdsOK" position="942,302" size="83,37"
                font="Regular;24" halign="right" foregroundColor="#01f76f"
                backgroundColor="#082136" transparent="1" />
        <widget zPosition="20" name="hddOK" position="942,356" size="83,37"
                font="Regular;24" halign="right" foregroundColor="#01f76f"
                backgroundColor="#082136" transparent="1" />

        <!-- backup -->
        <widget zPosition="20" name="targetSlot" position="210,518" size="330,36"
                font="Regular;25" foregroundColor="#f4f8fb"
                backgroundColor="#092b45" transparent="1" />
        <!-- r16: clear separation between backup button and progress area -->
        <widget zPosition="25" name="progressTitle" position="125,646" size="590,23"
                font="Regular;18" foregroundColor="#d8edf8"
                backgroundColor="#082136" transparent="1" />
        <widget zPosition="25" name="backupProgress" position="125,672" size="590,28"
                backgroundColor="#25465c" foregroundColor="#00dfff"
                borderWidth="1" borderColor="#71cdea" />
        <!-- percentage is centered directly on top of the progress bar -->
        <widget zPosition="30" name="progressPercent" position="125,670" size="590,31"
                font="Regular;20" halign="center" valign="center" foregroundColor="#f4f8fb"
                backgroundColor="#082136" transparent="1" />
        <widget zPosition="25" name="backupStatus" position="125,704" size="590,20"
                font="Regular;15" foregroundColor="#ffd400"
                backgroundColor="#082136" transparent="1" />

        <!-- r19: the baked-in static update artwork was removed from background.png.
             This is now the ONE dynamic button, so enabled/disabled states can never overlap. -->
        <widget zPosition="30" name="updateButton" position="937,512" size="610,58"
                font="Regular;29" halign="center" valign="center"
                foregroundColor="#f4f8fb" backgroundColor="#29465a"
                borderWidth="2" borderColor="#71cdea" />
        <widget zPosition="30" name="updateHint" position="950,576" size="585,28"
                font="Regular;17" halign="center" valign="center" foregroundColor="#b8d6e8"
                backgroundColor="#082136" transparent="1" />

        <!-- holdLine intentionally not rendered: approved checkbox/text stays untouched -->

        <!-- live output -->
        <widget zPosition="20" name="log" position="69,790" size="1068,166"
                font="Console;21" foregroundColor="#f4f8fb"
                backgroundColor="#000609" transparent="1" />

        <!-- rollback -->
        <widget zPosition="20" name="rollback" position="1360,793" size="258,110"
                font="Regular;21" foregroundColor="#f4f8fb"
                backgroundColor="#082136" transparent="1" />
        <!-- keyboard / remote focus cursor -->
        <widget zPosition="50" name="navCursor" position="184,516" size="22,40"
                font="Regular;28" foregroundColor="#00ecff" transparent="1" />

    </screen>
    '''.replace("__BACKGROUND_PATH__", _BACKGROUND_PATH)

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        global _SAFEUPDATE_UI_OPEN
        _SAFEUPDATE_UI_OPEN += 1
        try:
            self.onClose.append(self._rotation_screen_closed)
        except Exception:
            pass
        self.log_lines = []
        self.slots = []
        self.slot_index = 0
        self.busy = False
        self.backup_verified = False
        self.verified_backup_slot = None
        self.verified_backup_mode = None
        self.verified_backup_path = ""
        self.recovery_state = None
        self.pending_internal_backup = None
        self.pending_restore = None
        self.container = None
        self.pending_backup = None
        self.pending_delete = None
        self.backup_total_bytes = 0
        self.backup_dst = ""
        self.progress_value = 0

        for name in ("clock", "date", "boxHeader", "currentInfo", "currentOK", "kexecOK", "holdsOK", "hddOK", "targetSlot", "progressTitle", "progressPercent", "backupStatus", "updateButton", "updateHint", "holdLine", "log", "rollback", "navCursor"):
            self[name] = Label("")
        self["backupProgress"] = ProgressBar()
        self["backupProgress"].setRange((0, 100))
        self["backupProgress"].setValue(0)

        self["currentOK"].setText("●  OK")
        self["progressTitle"].setText("Backup-Fortschritt")
        self["progressPercent"].setText("0 %")
        self["backupStatus"].setText("Status: Noch kein Backup für dieses Update.")
        self["holdLine"].setText("Kernel-Pakete auf HOLD lassen")
        self["rollback"].setText("Noch kein Backup vorhanden.")
        self["navCursor"].setText(">")
        self.nav_focus = 5  # 0=currentInfo, 1=kexec, 2=holds, 3=hdd, 4=targetSlot, 5=backup, 6=update
        self.last_action_focus = 5

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions", "NumberActions"],
            {
                "cancel": self.close,
                "red": self.close,
                "yellow": self.start_backup,
                "green": self.start_update,
                "blue": self.show_details,
                "0": self.request_delete_backup,
                "7": self.force_rotation_now,
                "8": self.toggle_rotation,
                "9": self.restore_internal_backup,
                "left": self.nav_left,
                "right": self.nav_right,
                "up": self.nav_up,
                "down": self.nav_down,
                "ok": self.nav_ok,
            },
            -1,
        )

        self.timer = eTimer()
        try:
            self.timer.callback.append(self.update_clock)
        except Exception:
            try:
                self.timer.timeout.connect(self.update_clock)
            except Exception:
                pass

        self.progress_timer = eTimer()
        try:
            self.progress_timer.callback.append(self.update_backup_progress)
        except Exception:
            try:
                self.progress_timer.timeout.connect(self.update_backup_progress)
            except Exception:
                pass

        self.onLayoutFinish.append(self.startup)

    def _rotation_screen_closed(self):
        global _SAFEUPDATE_UI_OPEN
        if _SAFEUPDATE_UI_OPEN > 0:
            _SAFEUPDATE_UI_OPEN -= 1

    def startup(self):
        self.update_clock()
        self.update_box_identity()
        try:
            self.timer.start(30000, False)
        except Exception:
            pass
        self.append_log("> Prüfe Multiboot-Schutz...")
        self.refresh_status()
        self.refresh_slots()
        self.load_rollback()
        self.paint_update_state()
        self.paint_nav_focus()

    def update_box_identity(self):
        brand, model = detect_box_identity()
        display = (brand + (" " + model if model else "")).strip()
        if _USE_CLASSIC_VU_DUO4KSE:
            # The classic VU+ Duo 4K SE header is already part of the approved artwork.
            self["boxHeader"].setText("")
        else:
            self["boxHeader"].setText("%s  •  Multiboot Schutz" % display)
        self.append_log("> Receiver erkannt: %s" % display)

    def update_clock(self):
        now = datetime.now()
        self["clock"].setText(now.strftime("%H:%M"))
        weekdays = ("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So")
        months = ("Jan.", "Feb.", "Mär.", "Apr.", "Mai", "Jun.", "Jul.", "Aug.", "Sep.", "Okt.", "Nov.", "Dez.")
        self["date"].setText("%s, %d. %s %d" % (
            weekdays[now.weekday()],
            now.day,
            months[now.month - 1],
            now.year
        ))

    def set_status(self, name, ok):
        self[name].setText("●  OK" if ok else "●  FEHLER")
        try:
            self[name].instance.setForegroundColor(parseColor("#01f76f" if ok else "#ff4141"))
        except Exception:
            pass

    def refresh_status(self):
        info = image_info()
        slot = current_slot()
        version = info.get("version", "?")
        build = info.get("build", info.get("imagebuild", "?"))
        self["currentInfo"].setText("Slot %s    OpenATV %s    Build %s" % (slot if slot is not None else "?", version, build))
        self.set_status("kexecOK", kexec_ok())
        self.set_status("holdsOK", holds_ok())
        self.set_status("hddOK", hdd_ok())
        self.append_log("> KEXEC-Kernel: %s" % ("OK" if kexec_ok() else "FEHLER"))
        self.append_log("> Kernel-HOLDs: %s" % ("OK" if holds_ok() else "FEHLER"))
        self.append_log("> HDD /media/usb: %s" % ("OK" if hdd_ok() else "FEHLER"))

    def refresh_slots(self):
        previous = None
        if self.slots and 0 <= self.slot_index < len(self.slots):
            previous = self.slots[self.slot_index]

        self.slots = free_slots()

        if previous in self.slots:
            self.slot_index = self.slots.index(previous)
        else:
            self.slot_index = 0

        if self.slots:
            self["targetSlot"].setText("Slot %d – FREI" % self.slots[self.slot_index])
            self.append_log("> Verifizierte freie Slots: %s" % ", ".join(str(x) for x in self.slots))
        else:
            self["targetSlot"].setText("Internes eMMC")
            self.append_log("> Kein freier Multiboot-Slot – verwende internes eMMC-Sicherheitsbackup.")
            self.append_log("> Vorhandene Slots und Recovery werden nicht überschrieben.")

    def paint_nav_focus(self):
        """Move a minimal cursor without changing the approved layout."""
        try:
            positions = {
                0: (43, 188),    # current image first row
                1: (43, 247),    # KEXEC-Kernel
                2: (43, 302),    # Kernel-HOLDs
                3: (43, 356),    # HDD /media/usb
                4: (184, 516),   # target slot
                5: (43, 590),    # backup button
                6: (900, 520),   # update button
            }
            x, y = positions.get(self.nav_focus, positions[5])
            self["navCursor"].instance.move(ePoint(x, y))
            self["navCursor"].show()
        except Exception:
            pass

    def nav_left(self):
        if self.busy:
            return
        if self.nav_focus == 4:
            self.prev_slot()
        elif self.nav_focus == 6:
            self.nav_focus = 5
            self.last_action_focus = 5
            self.paint_nav_focus()

    def nav_right(self):
        if self.busy:
            return
        if self.nav_focus == 4:
            self.next_slot()
        elif self.nav_focus == 5:
            self.nav_focus = 6
            self.last_action_focus = 6
            self.paint_nav_focus()

    def nav_up(self):
        if self.busy:
            return
        mapping = {
            0: 0,
            1: 0,
            2: 1,
            3: 2,
            4: 3,
            5: 4,
            6: 4,
        }
        self.nav_focus = mapping.get(self.nav_focus, 5)
        self.paint_nav_focus()

    def nav_down(self):
        if self.busy:
            return
        mapping = {
            0: 1,
            1: 2,
            2: 3,
            3: 4,
            4: self.last_action_focus if self.last_action_focus in (5, 6) else 5,
            5: 5,
            6: 6,
        }
        self.nav_focus = mapping.get(self.nav_focus, 5)
        self.paint_nav_focus()

    def nav_ok(self):
        if self.busy:
            return
        if self.nav_focus == 6:
            self.start_update()
        elif self.nav_focus in (0, 1, 2, 3):
            self.show_details()
        else:
            self.start_backup()

    def prev_slot(self):
        if self.busy or not self.slots:
            return
        self.slot_index = (self.slot_index - 1) % len(self.slots)
        self["targetSlot"].setText("Slot %d – FREI" % self.slots[self.slot_index])

    def next_slot(self):
        if self.busy or not self.slots:
            return
        self.slot_index = (self.slot_index + 1) % len(self.slots)
        self["targetSlot"].setText("Slot %d – FREI" % self.slots[self.slot_index])

    def set_backup_progress(self, value, title=None, status=None):
        try:
            value = max(0, min(100, int(value)))
        except Exception:
            value = 0
        self.progress_value = value
        try:
            self["backupProgress"].setValue(value)
            self["progressPercent"].setText("%d %%" % value)
            if title is not None:
                self["progressTitle"].setText(str(title))
            if status is not None:
                self["backupStatus"].setText(str(status))
        except Exception:
            pass

    def update_backup_progress(self):
        if not self.busy or not self.backup_dst or self.backup_total_bytes <= 0:
            return
        try:
            if not os.path.isdir(self.backup_dst):
                return
            copied = tree_size_bytes(self.backup_dst)
            if copied <= 0:
                return
            ratio = min(1.0, float(copied) / float(self.backup_total_bytes))
            value = 10 + int(ratio * 82)
            if value > self.progress_value and value <= 92:
                self.set_backup_progress(value, "Backup-Fortschritt – Kopieren", "Status: Kopiere aktuelles Image ...")
        except Exception:
            pass

    def append_log(self, text):
        for line in str(text).replace("\r", "").split("\n"):
            if line:
                self.log_lines.append(line)
        self.log_lines = self.log_lines[-7:]
        self["log"].setText("\n".join(self.log_lines))
        try:
            with open(LOG_FILE, "a") as f:
                f.write(str(text) + "\n")
        except Exception:
            pass

    def load_rollback(self):
        self.recovery_state = None
        st = load_state()

        # r32: internal eMMC backup metadata is also stored on the shared
        # multiboot filesystem. This lets another slot discover and restore it.
        internal = None
        if st.get("backup_mode") == "internal":
            internal = validate_internal_backup_state(st)
        if internal is None:
            candidates = discover_internal_backups()
            if candidates:
                current = current_slot()
                same_source = [x for x in candidates if int(x.get("source_slot", -1)) == current]
                internal = same_source[0] if same_source else candidates[0]

        if internal is not None:
            source = int(internal.get("source_slot"))
            if source == current_slot():
                internal = ensure_rotation_state(_merge_rotation_fields(internal, st))
            self.recovery_state = internal
            self.verified_backup_mode = "internal"
            self.verified_backup_path = internal.get("_backup_dir", "")
            created = (internal.get("created") or "?").split(" ")[0]
            if source == current_slot():
                self.backup_verified = True
                self.verified_backup_slot = None
                self["targetSlot"].setText("Internes eMMC – VERIFIZIERT ✓")
                self.set_backup_progress(100, "Backup-Fortschritt – Fertig", rotation_status_text(internal))
                self["rollback"].setText("Backup: Internes eMMC\nQuelle: Slot %s\nErstellt: %s\n0 = BACKUP LÖSCHEN" % (source, created))
                self.append_log("> Internes eMMC-Backup erneut geprüft: Slot %s OK." % source)
            else:
                # A backup of another slot is a recovery source, not permission
                # to update the currently running slot.
                self.backup_verified = False
                self.verified_backup_slot = None
                self["rollback"].setText("eMMC-Backup: OK\nQuelle: Slot %s\nStatus: verifiziert\n9 = WIEDERHERSTELLEN" % source)
                self.append_log("> Notfall-Backup von Slot %s gefunden. Taste 9 = Wiederherstellen." % source)
            return

        # Existing bootable-slot backup mode remains unchanged.
        valid = False
        target = st.get("target_slot")
        source = st.get("source_slot")
        if st.get("verified") and st.get("backup_mode", "slot") == "slot" and source == current_slot() and target is not None:
            try:
                target = int(target)
                info = compatible_startup_slots().get(target)
                mp = ensure_full_mount(False)
                if info and mp:
                    dst = os.path.join(mp, info["rootsubdir"])
                    valid = slot_backup_valid(target, dst, st.get("kernel_sha256", ""))
            except Exception:
                valid = False

        if valid:
            st = ensure_rotation_state(st)
            self.backup_verified = True
            self.verified_backup_slot = target
            self.verified_backup_mode = "slot"
            self.verified_backup_path = ""
            self["targetSlot"].setText("Slot %s – VERIFIZIERT ✓" % target)
            self.set_backup_progress(100, "Backup-Fortschritt – Fertig", rotation_status_text(st))
            created = (st.get("created") or "?").split(" ")[0]
            self["rollback"].setText("Backup-Slot:  %s\nQuelle:       Slot %s\nErstellt:     %s\n0 = BACKUP LÖSCHEN" % (target, source, created))
            self.append_log("> Gespeichertes Backup erneut geprüft: Slot %s OK." % target)
        elif st.get("verified"):
            self.backup_verified = False
            self.verified_backup_slot = None
            self.verified_backup_mode = None
            self.verified_backup_path = ""
            self.set_backup_progress(0, "Backup-Fortschritt", "Status: Gespeichertes Backup fehlt – Update gesperrt.")
            self["rollback"].setText("Noch kein gültiges Backup vorhanden.")
            self.append_log("> Alter Backup-Status verworfen: Backup physisch nicht mehr verifizierbar.")
            try:
                st["verified"] = False
                st["invalidated"] = datetime.now().strftime("%d.%m.%Y %H:%M")
                save_state(st)
            except Exception:
                pass

    def paint_update_state(self):
        """Paint update availability; safety operations get a real red lock overlay."""
        try:
            self["updateHint"].show()
            if self.busy:
                lock_text = "UPDATE GESPERRT – BACKUP LÄUFT"
                lock_hint = "Sicherheitsbackup wird erstellt und verifiziert."
                if self.pending_delete is not None:
                    lock_text = "UPDATE GESPERRT – LÖSCHEN LÄUFT"
                    lock_hint = "Sicherheitsvorgang wird abgeschlossen."
                elif self.pending_restore is not None:
                    lock_text = "UPDATE GESPERRT – WIEDERHERSTELLUNG"
                    lock_hint = "Notfall-Rückkehr wird sicher abgeschlossen."
                self["updateButton"].setText(lock_text)
                self["updateButton"].show()
                self["updateHint"].setText(lock_hint)
                try:
                    self["updateButton"].instance.setBackgroundColor(parseColor("#9b111e"))
                    self["updateButton"].instance.setForegroundColor(parseColor("#ffffff"))
                    self["updateButton"].instance.setBorderColor(parseColor("#ff5a5f"))
                    self["updateHint"].instance.setForegroundColor(parseColor("#ffb3b8"))
                except Exception:
                    pass
            elif self.backup_verified:
                # The enabled button is baked into background.png; hide the overlay.
                self["updateButton"].hide()
                self["updateHint"].setText("Backup verifiziert – Update freigegeben")
                try:
                    self["updateHint"].instance.setForegroundColor(parseColor("#55e8ff"))
                except Exception:
                    pass
            else:
                self["updateButton"].setText("OPENATV UPDATE STARTEN")
                self["updateButton"].show()
                self["updateHint"].setText("Wird nach erfolgreichem Backup freigeschaltet.")
                try:
                    self["updateButton"].instance.setBackgroundColor(parseColor("#29465a"))
                    self["updateButton"].instance.setForegroundColor(parseColor("#a9bdca"))
                    self["updateButton"].instance.setBorderColor(parseColor("#71cdea"))
                    self["updateHint"].instance.setForegroundColor(parseColor("#b8d6e8"))
                except Exception:
                    pass
        except Exception:
            pass

    def connect_container(self, data_cb, close_cb):
        self.container = eConsoleAppContainer()
        try:
            self.container.dataAvail.append(data_cb)
            self.container.appClosed.append(close_cb)
        except Exception:
            self.container.dataAvail.connect(data_cb)
            self.container.appClosed.connect(close_cb)

    def start_internal_backup(self):
        if self.busy:
            return
        source = current_slot()
        if source is None:
            self.session.open(MessageBox, "Aktiver Quellslot konnte nicht eindeutig erkannt werden.", MessageBox.TYPE_ERROR)
            return
        if source not in compatible_startup_slots():
            self.session.open(MessageBox, "Aktiver Slot ist nicht eindeutig in STARTUP_N verifiziert.", MessageBox.TYPE_ERROR)
            return

        mp = ensure_full_mount(True)
        if not mp:
            self.session.open(MessageBox, "Internes Multiboot-Dateisystem konnte nicht sicher schreibbar geöffnet werden.", MessageBox.TYPE_ERROR)
            return
        src = active_source_path(mp)
        if not src or not slot_root_tree_valid(src):
            self.session.open(MessageBox, "Aktuelles Image konnte nicht vollständig verifiziert werden.", MessageBox.TYPE_ERROR)
            return

        backup_dir = internal_backup_dir(source, mp)
        if not internal_backup_path_is_safe(backup_dir, source, mp):
            self.session.open(MessageBox, "Interner Backup-Pfad besteht die Sicherheitsprüfung nicht.", MessageBox.TYPE_ERROR)
            return
        base = internal_backup_base(mp)
        if os.path.lexists(base) and (not os.path.isdir(base) or os.path.islink(base)):
            self.session.open(MessageBox, "Interner SafeUpdate-Bereich ist nicht sicher nutzbar.", MessageBox.TYPE_ERROR)
            return
        if os.path.lexists(backup_dir):
            existing = validate_internal_backup_state(read_json_file(os.path.join(backup_dir, INTERNAL_BACKUP_META)), mp)
            if existing:
                self.session.open(MessageBox, "Für Slot %d existiert bereits ein verifiziertes internes Backup.\n\nTaste 0 löscht ausschließlich dieses SafeUpdate-Backup." % source, MessageBox.TYPE_INFO)
            else:
                self.session.open(MessageBox, "Im internen SafeUpdate-Bereich liegt ein unvollständiges Backup.\nEs wird aus Sicherheitsgründen nicht überschrieben.", MessageBox.TYPE_ERROR)
            return

        source_bytes = tree_size_bytes(src)
        kernel_bytes = block_device_size(active_kernel_device()) if is_gbtrio4k() else 0
        free_bytes = filesystem_free_bytes(mp)
        reserve = 128 * 1024 * 1024
        needed = source_bytes + kernel_bytes + reserve
        if source_bytes <= 0 or free_bytes <= 0:
            self.session.open(MessageBox, "Freier eMMC-Speicher bzw. Backup-Größe konnte nicht sicher ermittelt werden.", MessageBox.TYPE_ERROR)
            return
        if free_bytes < needed:
            self.session.open(
                MessageBox,
                "Nicht genug freier interner eMMC-Speicher.\n\nBenötigt: ca. %d MB inkl. Reserve\nFrei: ca. %d MB" % (needed // (1024 * 1024), free_bytes // (1024 * 1024)),
                MessageBox.TYPE_ERROR,
            )
            return

        self.append_log("> Kein freier Slot – internes eMMC-Backup gewählt.")
        self.append_log("> Backup-Bereich: /%s/slot%d" % (INTERNAL_BACKUP_DIRNAME, source))
        self.append_log("> Freier eMMC-Speicher: %d MB" % (free_bytes // (1024 * 1024)))
        self.session.openWithCallback(
            lambda yes: self.do_internal_backup(yes, source, src, backup_dir, source_bytes),
            MessageBox,
            "Internes Sicherheitsbackup von Slot %d anlegen?\n\n"
            "Kein vorhandener Multiboot-Slot wird verändert.\n"
            "Recovery bleibt unangetastet.\n"
            "Das Backup liegt separat unter /%s/." % (source, INTERNAL_BACKUP_DIRNAME),
            MessageBox.TYPE_YESNO,
        )

    def do_internal_backup(self, yes, source, src, backup_dir, source_bytes):
        if not yes or self.busy:
            return
        mp = ensure_full_mount(True)
        if not mp or not internal_backup_path_is_safe(backup_dir, source, mp):
            self.session.open(MessageBox, "Backup abgebrochen: interner Zielpfad ist nicht mehr eindeutig.", MessageBox.TYPE_ERROR)
            return
        if os.path.lexists(backup_dir):
            self.session.open(MessageBox, "Backup abgebrochen: interner Zielpfad existiert inzwischen.", MessageBox.TYPE_ERROR)
            return
        if os.path.realpath(src) == os.path.realpath(backup_dir) or os.path.realpath(backup_dir).startswith(os.path.realpath(src).rstrip("/") + "/"):
            self.session.open(MessageBox, "Backup abgebrochen: Ziel liegt unerwartet im Quellimage.", MessageBox.TYPE_ERROR)
            return

        base = internal_backup_base(mp)
        rootfs = os.path.join(backup_dir, "rootfs")
        self.busy = True
        self.backup_verified = False
        self.paint_update_state()
        self.backup_total_bytes = int(source_bytes or 0)
        self.backup_dst = rootfs
        self.pending_internal_backup = (source, backup_dir, src)
        self.set_backup_progress(3, "Backup-Fortschritt – Prüfen", "Status: Internes eMMC-Backup wird vorbereitet ...")
        try:
            self.progress_timer.start(1500, False)
        except Exception:
            pass

        if is_gbtrio4k():
            src_kernel = active_kernel_device()
            if not gigablue_kernel_layout_ok() or not src_kernel or not os.path.exists(src_kernel):
                self.busy = False
                self.pending_internal_backup = None
                self.backup_dst = ""
                self.session.open(MessageBox, "GigaBlue Kernelquelle ist nicht sicher verifizierbar.", MessageBox.TYPE_ERROR)
                return
            script = """
set -e
BASE={base}
DST={dst}
ROOTFS="$DST/rootfs"
SRC={src}
SRC_KERNEL={src_kernel}
if [ -e "$BASE" ]; then test -d "$BASE"; test ! -L "$BASE"; else mkdir "$BASE"; fi
test ! -L "$BASE"
test ! -e "$DST"
mkdir "$DST"
mkdir "$ROOTFS"
echo 'Internes Backup-Ziel ist weiterhin frei.'
echo 'Synchronisiere Dateisystem...'
sync
echo 'Kopiere Image...'
cp -a "$SRC"/. "$ROOTFS"/
sync
test -f "$ROOTFS/etc/image-version"
test -e "$ROOTFS/sbin/init"
test -f "$ROOTFS/usr/bin/enigma2"
echo 'Kopiere GigaBlue Kernel in Sicherheitsdatei...'
dd if="$SRC_KERNEL" of="$DST/kernel.img" bs=1048576 conv=fsync 2>/dev/null
sync
SRC_HASH=$(sha256sum "$SRC_KERNEL" | awk '{{print $1}}')
DST_HASH=$(sha256sum "$DST/kernel.img" | awk '{{print $1}}')
echo "Quelle zImage: $SRC_HASH"
echo "Backup zImage: $DST_HASH"
[ -n "$SRC_HASH" ]
[ "$SRC_HASH" = "$DST_HASH" ] || exit 22
echo 'BACKUP_VERIFIED'
""".format(base=shq(base), dst=shq(backup_dir), src=shq(src), src_kernel=shq(src_kernel))
        else:
            script = """
set -e
BASE={base}
DST={dst}
ROOTFS="$DST/rootfs"
SRC={src}
if [ -e "$BASE" ]; then test -d "$BASE"; test ! -L "$BASE"; else mkdir "$BASE"; fi
test ! -L "$BASE"
test ! -e "$DST"
mkdir "$DST"
mkdir "$ROOTFS"
echo 'Internes Backup-Ziel ist weiterhin frei.'
echo 'Synchronisiere Dateisystem...'
sync
echo 'Kopiere Image...'
cp -a "$SRC"/. "$ROOTFS"/
sync
test -f "$ROOTFS/zImage"
test -f "$ROOTFS/etc/image-version"
SRC_HASH=$(sha256sum "$SRC/zImage" | awk '{{print $1}}')
DST_HASH=$(sha256sum "$ROOTFS/zImage" | awk '{{print $1}}')
echo "Quelle zImage: $SRC_HASH"
echo "Backup zImage: $DST_HASH"
[ -n "$SRC_HASH" ]
[ "$SRC_HASH" = "$DST_HASH" ] || exit 22
echo 'BACKUP_VERIFIED'
""".format(base=shq(base), dst=shq(backup_dir), src=shq(src))

        self.append_log("> Internes eMMC-Sicherheitsbackup startet...")
        self.connect_container(self.backup_data, self.internal_backup_closed)
        self.container.execute("/bin/sh -c %s" % shq(script))

    def internal_backup_closed(self, rc):
        try:
            self.progress_timer.stop()
        except Exception:
            pass
        self.busy = False
        pending = self.pending_internal_backup
        self.pending_internal_backup = None
        if not pending:
            return
        source, backup_dir, src = pending
        rootfs = os.path.join(backup_dir, "rootfs")
        verified = (rc == 0 and slot_root_tree_valid(rootfs))
        kernel_hash = ""
        kernel_size = 0
        if verified:
            if is_gbtrio4k():
                src_kernel = active_kernel_device()
                kernel_file = os.path.join(backup_dir, "kernel.img")
                kernel_hash = sha256_prefix(src_kernel) if src_kernel else ""
                verified = bool(kernel_hash and os.path.isfile(kernel_file) and sha256_prefix(kernel_file) == kernel_hash)
                kernel_size = block_device_size(src_kernel) if src_kernel else 0
                if verified and kernel_size > 0:
                    try:
                        verified = os.path.getsize(kernel_file) == kernel_size
                    except Exception:
                        verified = False
            else:
                src_z = os.path.join(src, "zImage")
                dst_z = os.path.join(rootfs, "zImage")
                kernel_hash = sha256_prefix(src_z)
                verified = bool(kernel_hash and os.path.isfile(dst_z) and sha256_prefix(dst_z) == kernel_hash)

        image_hash = sha256_prefix(os.path.join(rootfs, "etc", "image-version")) if verified else ""
        if not image_hash:
            verified = False

        if verified:
            created = datetime.now().strftime("%d.%m.%Y %H:%M")
            meta = {
                "backup_mode": "internal",
                "source_slot": int(source),
                "created": created,
                "created_sort": datetime.now().strftime("%Y%m%d%H%M%S"),
                "verified": True,
                "build": image_info().get("build", ""),
                "root_device": root_device(),
                "backup_rel": "%s/slot%d" % (INTERNAL_BACKUP_DIRNAME, source),
                "kernel_sha256": kernel_hash,
                "kernel_size": kernel_size,
                "image_version_sha256": image_hash,
            }
            meta = _rotation_seed(meta, True)
            if is_gbtrio4k():
                meta["kernel_source_device"] = active_kernel_device()
            if save_json_file(os.path.join(backup_dir, INTERNAL_BACKUP_META), meta):
                checked = validate_internal_backup_state(meta)
            else:
                checked = None
            verified = checked is not None

        if verified:
            save_state(meta)
            self.backup_verified = True
            self.verified_backup_slot = None
            self.verified_backup_mode = "internal"
            self.verified_backup_path = backup_dir
            self.recovery_state = checked
            self.set_backup_progress(100, "Backup-Fortschritt – Fertig", rotation_status_text(meta))
            self["targetSlot"].setText("Internes eMMC – VERIFIZIERT ✓")
            self["rollback"].setText("Backup: Internes eMMC\nQuelle: Slot %d\nStatus: verifiziert\n0 = BACKUP LÖSCHEN" % source)
            self.append_log("> Internes eMMC-Backup verifiziert. Update freigegeben.")
            self.nav_focus = 6
            self.last_action_focus = 6
            self.paint_nav_focus()
        else:
            self.backup_verified = False
            self.verified_backup_mode = None
            self.set_backup_progress(self.progress_value, "Backup-Fortschritt – FEHLER", "Status: Internes Backup nicht vollständig verifiziert.")
            self.append_log("> FEHLER: Internes eMMC-Backup nicht verifiziert.")
            self.session.open(MessageBox, "Internes eMMC-Backup konnte nicht vollständig verifiziert werden.\nDas Update bleibt gesperrt.", MessageBox.TYPE_ERROR)
        self.paint_update_state()
        self.backup_dst = ""
        self.backup_total_bytes = 0

    def start_backup(self):
        if self.busy:
            return
        if is_gbtrio4k() and not gigablue_kernel_layout_ok():
            self.session.open(MessageBox, "GigaBlue Kernel-/Slot-Struktur ist nicht eindeutig verifizierbar.\nBackup bleibt gesperrt.", MessageBox.TYPE_ERROR)
            return
        # A verified backup stays visible after success. When the user explicitly
        # starts another backup, switch the field back to the selected free target.
        if self.backup_verified and self.slots:
            self["targetSlot"].setText("Slot %d – FREI" % self.slots[self.slot_index])

        if not self.slots:
            self.start_internal_backup()
            return

        # Selected target from the last verified scan.
        if self.slot_index < 0 or self.slot_index >= len(self.slots):
            self.refresh_slots()
            return

        target = self.slots[self.slot_index]
        source = current_slot()

        # SECURITY CHECK #1:
        # Re-scan immediately before doing anything writable. Never trust the
        # slot list from screen startup because another tool may have changed it.
        latest_free = free_slots()
        if target not in latest_free:
            self.append_log("> ABBRUCH: Zielslot %d ist nicht mehr verifiziert frei." % target)
            self.refresh_slots()
            self.session.open(
                MessageBox,
                "Zielslot %d ist nicht mehr eindeutig frei.\\n\\n"
                "Es wurde nichts verändert." % target,
                MessageBox.TYPE_ERROR
            )
            return

        if source is None:
            self.append_log("> ABBRUCH: Aktiver Quellslot nicht eindeutig erkannt.")
            self.session.open(
                MessageBox,
                "Aktiver Quellslot konnte nicht eindeutig erkannt werden.\\n"
                "Es wurde nichts verändert.",
                MessageBox.TYPE_ERROR
            )
            return

        target_info = compatible_startup_slots().get(target)
        if not target_info:
            self.append_log("> ABBRUCH: STARTUP_%d ist nicht kompatibel." % target)
            self.refresh_slots()
            self.session.open(
                MessageBox,
                "STARTUP_%d ist nicht sicher für dieses Backup nutzbar.\\n"
                "Es wurde nichts verändert." % target,
                MessageBox.TYPE_ERROR
            )
            return

        # Switch/create the full view as writable only now, immediately before
        # the confirmed backup flow.
        mp = ensure_full_mount(True)
        if not mp:
            self.append_log("> ABBRUCH: Vollständiger Multiboot-Mount nicht schreibbar.")
            self.session.open(
                MessageBox,
                "Multiboot-Datenträger konnte nicht sicher schreibbar geöffnet werden.\\n"
                "Es wurde nichts verändert.",
                MessageBox.TYPE_ERROR
            )
            return

        src = active_source_path(mp)
        dst = os.path.join(mp, target_info["rootsubdir"])

        # SECURITY CHECK #2:
        # Re-check source and target on the actual writable full mount.
        if not src or not os.path.isdir(src):
            self.append_log("> ABBRUCH: Quellpfad fehlt: %s" % (src or "?"))
            self.session.open(
                MessageBox,
                "Quellslot konnte im vollständigen Multiboot-Dateisystem nicht verifiziert werden.\\n"
                "Es wurde nichts verändert.",
                MessageBox.TYPE_ERROR
            )
            return

        if not slot_root_tree_valid(src):
            self.append_log("> ABBRUCH: Quellslot %d ist unvollständig." % source)
            self.session.open(
                MessageBox,
                "Quellslot %d ist nicht vollständig verifizierbar.\\n"
                "Es wurde nichts verändert." % source,
                MessageBox.TYPE_ERROR
            )
            return

        if os.path.lexists(dst) and not is_strictly_empty_dir(dst):
            self.append_log("> ABBRUCH: Zielpfad existiert bereits: %s" % dst)
            self.refresh_slots()
            self.session.open(
                MessageBox,
                "Zielslot %d ist nicht mehr frei.\n\n"
                "Es wurde nichts überschrieben." % target,
                MessageBox.TYPE_ERROR
            )
            return
        if is_strictly_empty_dir(dst):
            self.append_log("> Leerer OpenATV-Rest in Slot %d erkannt (wird erst nach Bestätigung entfernt)." % target)

        # STARTUP_N itself must still exist and remain valid. It is never
        # overwritten by SafeUpdate2026; it defines which slots the box offers.
        live_target_info = parse_startup_text(
            target,
            read_text(target_info["path"]),
            target_info["path"]
        )
        if not live_target_info or not same_device(live_target_info["root_device"], root_device()):
            self.append_log("> ABBRUCH: STARTUP_%d änderte sich während der Prüfung." % target)
            self.refresh_slots()
            self.session.open(
                MessageBox,
                "Die Bootdefinition von Slot %d ist nicht mehr eindeutig.\\n"
                "Es wurde nichts verändert." % target,
                MessageBox.TYPE_ERROR
            )
            return

        # Space check before the confirmation dialog.
        source_bytes = tree_size_bytes(src)
        free_bytes = filesystem_free_bytes(mp)
        reserve = 64 * 1024 * 1024
        if source_bytes <= 0 or free_bytes <= 0:
            self.append_log("> ABBRUCH: Speicherbedarf konnte nicht sicher geprüft werden.")
            self.session.open(
                MessageBox,
                "Freier Speicher bzw. Backup-Größe konnte nicht sicher ermittelt werden.\\n"
                "Backup bleibt gesperrt.",
                MessageBox.TYPE_ERROR
            )
            return

        if free_bytes < source_bytes + reserve:
            self.append_log("> ABBRUCH: Nicht genug freier Speicher für Slot %d." % target)
            self.session.open(
                MessageBox,
                "Nicht genug freier Speicher für ein vollständiges Backup.\\n\\n"
                "Benötigt: ca. %d MB + 64 MB Reserve\\n"
                "Frei: ca. %d MB" % (
                    source_bytes // (1024 * 1024),
                    free_bytes // (1024 * 1024)
                ),
                MessageBox.TYPE_ERROR
            )
            return

        self.append_log("> Quelle verifiziert: Slot %d" % source)
        self.append_log("> Ziel verifiziert frei: Slot %d" % target)
        self.append_log("> STARTUP_%d: OK (wird nicht verändert)" % target)

        self.session.openWithCallback(
            lambda yes: self.do_backup(yes, source, target, src, dst, source_bytes),
            MessageBox,
            "Backup von Slot %d nach Slot %d anlegen?\\n\\n"
            "Der Zielslot wurde unmittelbar vorher zweimal geprüft.\\n"
            "Bestehende Slots werden niemals überschrieben." % (source, target),
            MessageBox.TYPE_YESNO,
        )

    def do_backup(self, yes, source, target, src, dst, source_bytes):
        if not yes:
            return

        # Final race check after the user's confirmation.
        if os.path.lexists(dst):
            if is_strictly_empty_dir(dst):
                try:
                    os.rmdir(dst)
                    self.append_log("> Leeren Slot-Rest %d sicher entfernt." % target)
                except Exception:
                    self.append_log("> ABBRUCH: Leerer Zielrest konnte nicht entfernt werden.")
                    return
            else:
                self.append_log("> ABBRUCH: Zielslot %d wurde zwischenzeitlich belegt." % target)
                self.refresh_slots()
                self.session.open(
                    MessageBox,
                    "Zielslot %d ist inzwischen nicht mehr frei.\n"
                    "Es wurde nichts überschrieben." % target,
                    MessageBox.TYPE_ERROR
                )
                return

        self.busy = True
        self.backup_verified = False
        self.paint_update_state()
        self.backup_total_bytes = int(source_bytes or 0)
        self.backup_dst = dst
        self.set_backup_progress(3, "Backup-Fortschritt – Prüfen", "Status: Backup wird vorbereitet ...")
        try:
            self.progress_timer.start(1500, False)
        except Exception:
            pass
        self.append_log("> Backup Slot %d -> Slot %d startet..." % (source, target))

        if is_gbtrio4k():
            src_kernel = active_kernel_device()
            dst_kernel = kernel_device_for_slot(target)
            if (not gigablue_kernel_layout_ok() or not src_kernel or not dst_kernel or
                    src_kernel == dst_kernel or dst_kernel != expected_kernel_device(target)):
                self.busy = False
                self.backup_dst = ""
                self.backup_total_bytes = 0
                self.set_backup_progress(0, "Backup-Fortschritt – FEHLER", "Status: GigaBlue Kernel-Slot nicht sicher verifizierbar.")
                self.session.open(MessageBox, "GigaBlue Kernel-Slot ist nicht sicher verifizierbar.\nEs wurde kein Backup gestartet.", MessageBox.TYPE_ERROR)
                return
            script = """
set -e
SRC={src}
DST={dst}
SRC_KERNEL={src_kernel}
DST_KERNEL={dst_kernel}

test -d "$SRC"
test -f "$SRC/etc/image-version"
test -e "$SRC/sbin/init"
test -f "$SRC/usr/bin/enigma2"
test -b "$SRC_KERNEL"
test -b "$DST_KERNEL"
test ! -e "$DST"

echo 'Zielslot ist weiterhin frei.'
mkdir "$DST"
echo 'Synchronisiere Dateisystem...'
sync
echo 'Kopiere Image...'
cp -a "$SRC"/. "$DST"/
sync

test -f "$DST/etc/image-version"
test -e "$DST/sbin/init"
test -f "$DST/usr/bin/enigma2"

echo 'Kopiere GigaBlue Kernel-Slot...'
dd if="$SRC_KERNEL" of="$DST_KERNEL" bs=1048576 conv=fsync 2>/dev/null
sync
SRC_HASH=$(sha256sum "$SRC_KERNEL" | awk '{{print $1}}')
DST_HASH=$(sha256sum "$DST_KERNEL" | awk '{{print $1}}')
echo "Quelle zImage: $SRC_HASH"
echo "Backup zImage: $DST_HASH"
[ -n "$SRC_HASH" ]
[ "$SRC_HASH" = "$DST_HASH" ] || exit 22

echo 'BACKUP_VERIFIED'
""".format(src=shq(src), dst=shq(dst), src_kernel=shq(src_kernel), dst_kernel=shq(dst_kernel))
        else:
            script = """
set -e
SRC={src}
DST={dst}

test -d "$SRC"
test -f "$SRC/zImage"
test -f "$SRC/etc/image-version"
test ! -e "$DST"

echo 'Zielslot ist weiterhin frei.'
mkdir "$DST"
echo 'Synchronisiere Dateisystem...'
sync
echo 'Kopiere Image...'
cp -a "$SRC"/. "$DST"/
sync

test -f "$DST/zImage"
test -f "$DST/etc/image-version"

SRC_HASH=$(sha256sum "$SRC/zImage" | awk '{{print $1}}')
DST_HASH=$(sha256sum "$DST/zImage" | awk '{{print $1}}')
echo "Quelle zImage: $SRC_HASH"
echo "Backup zImage: $DST_HASH"
[ "$SRC_HASH" = "$DST_HASH" ] || exit 22

echo 'BACKUP_VERIFIED'
""".format(src=shq(src), dst=shq(dst))

        self.pending_backup = (source, target, dst)
        self.connect_container(self.backup_data, self.backup_closed)
        self.container.execute("/bin/sh -c %s" % shq(script))

    def backup_data(self, data):
        try:
            txt = data.decode("utf-8", "replace")
        except Exception:
            txt = str(data)
        for line in txt.splitlines():
            self.append_log("> " + line)
            low = line.lower()
            if "zielslot ist weiterhin frei" in low:
                self.set_backup_progress(max(self.progress_value, 6), "Backup-Fortschritt – Prüfen", "Status: Zielslot geprüft ...")
            elif "synchronisiere dateisystem" in low:
                self.set_backup_progress(max(self.progress_value, 8), "Backup-Fortschritt – Vorbereiten", "Status: Dateisystem wird synchronisiert ...")
            elif "kopiere image" in low:
                self.set_backup_progress(max(self.progress_value, 10), "Backup-Fortschritt – Kopieren", "Status: Kopiere aktuelles Image ...")
            elif "quelle zimage" in low or "backup zimage" in low:
                self.set_backup_progress(max(self.progress_value, 95), "Backup-Fortschritt – Verifizieren", "Status: Prüfe Kernel und Integrität ...")
            elif "backup_verified" in low:
                self.set_backup_progress(99, "Backup-Fortschritt – Verifizieren", "Status: Abschlussprüfung ...")

    def backup_closed(self, rc):
        try:
            self.progress_timer.stop()
        except Exception:
            pass
        self.busy = False
        source, target, dst = self.pending_backup
        verified = rc == 0 and slot_backup_valid(target, dst)
        if verified:
            self.backup_verified = True
            self.verified_backup_slot = target
            self.verified_backup_mode = "slot"
            self.verified_backup_path = ""
            created = datetime.now().strftime("%d.%m.%Y %H:%M")
            state = {"backup_mode": "slot", "source_slot": source, "target_slot": target, "created": created, "created_sort": datetime.now().strftime("%Y%m%d%H%M%S"), "verified": True, "build": image_info().get("build", "")}
            state = _rotation_seed(state, True)
            if is_gbtrio4k():
                state["kernel_device"] = kernel_device_for_slot(target)
                state["kernel_sha256"] = sha256_prefix(state["kernel_device"])
            save_state(state)
            self.set_backup_progress(100, "Backup-Fortschritt – Fertig", rotation_status_text(state))
            self["rollback"].setText("Backup-Slot:  %d\nQuelle:       Slot %d\nErstellt:     %s\n0 = BACKUP LÖSCHEN" % (target, source, created.split(" ")[0]))
            self.append_log("> Backup verifiziert. Update freigegeben.")
            self.refresh_slots()
            self["targetSlot"].setText("Slot %d – VERIFIZIERT ✓" % target)
            self.nav_focus = 6
            self.last_action_focus = 6
            self.paint_nav_focus()
        else:
            self.set_backup_progress(self.progress_value, "Backup-Fortschritt – FEHLER", "Status: Backup FEHLGESCHLAGEN – Zielslot nicht verwenden.")
            self.append_log("> FEHLER: Backup nicht verifiziert.")
            self.session.open(MessageBox, "Backup konnte nicht verifiziert werden.\nDer Zielslot wurde NICHT automatisch gelöscht.", MessageBox.TYPE_ERROR)
        self.paint_update_state()
        self.backup_dst = ""
        self.backup_total_bytes = 0

    def request_delete_internal_backup(self):
        candidate = None
        if isinstance(self.recovery_state, dict) and self.recovery_state.get("backup_mode") == "internal":
            candidate = self.recovery_state
        if candidate is None:
            st = load_state()
            if st.get("backup_mode") == "internal":
                candidate = validate_internal_backup_state(st)
        if candidate is None:
            found = discover_internal_backups()
            candidate = found[0] if found else None
        if candidate is None:
            self.session.open(MessageBox, "Kein verifiziertes internes SafeUpdate-Backup zum Löschen vorhanden.", MessageBox.TYPE_INFO)
            return

        mp = ensure_full_mount(True)
        checked = validate_internal_backup_state(candidate, mp) if mp else None
        if checked is None:
            self.session.open(MessageBox, "KILLSWITCH blockiert: Internes Backup ist nicht mehr eindeutig verifizierbar.", MessageBox.TYPE_ERROR)
            return
        source = int(checked.get("source_slot"))
        backup_dir = checked.get("_backup_dir", "")
        if not internal_backup_path_is_safe(backup_dir, source, mp):
            self.session.open(MessageBox, "KILLSWITCH blockiert: Backup-Pfad ist nicht sicher.", MessageBox.TYPE_ERROR)
            return

        self.session.openWithCallback(
            lambda yes: self.do_delete_internal_backup(yes, checked),
            MessageBox,
            "KILLSWITCH: Internes Backup von Slot %d wirklich löschen?\n\n"
            "Gelöscht wird ausschließlich /%s/slot%d.\n"
            "Kein linuxrootfs-Slot, keine Kernelpartition und Recovery werden verändert.\n\n"
            "Das OpenATV-Update wird anschließend wieder gesperrt." % (source, INTERNAL_BACKUP_DIRNAME, source),
            MessageBox.TYPE_YESNO,
        )

    def do_delete_internal_backup(self, yes, state):
        if not yes or self.busy:
            return
        mp = ensure_full_mount(True)
        checked = validate_internal_backup_state(state, mp) if mp else None
        if checked is None:
            self.session.open(MessageBox, "Löschen abgebrochen: Backup konnte nicht erneut verifiziert werden.", MessageBox.TYPE_ERROR)
            return
        source = int(checked.get("source_slot"))
        backup_dir = checked.get("_backup_dir", "")
        if not internal_backup_path_is_safe(backup_dir, source, mp):
            self.session.open(MessageBox, "Löschen abgebrochen: Backup-Pfad hat sich geändert.", MessageBox.TYPE_ERROR)
            return

        self.busy = True
        self.backup_verified = False
        self.paint_update_state()
        self.pending_delete = ("internal", source, backup_dir)
        self.set_backup_progress(0, "Backup-Fortschritt – Löschen", "Status: Lösche internes Sicherheitsbackup ...")
        self.append_log("> KILLSWITCH: Lösche ausschließlich /%s/slot%d ..." % (INTERNAL_BACKUP_DIRNAME, source))
        base = internal_backup_base(mp)
        script = """
set -e
DST={dst}
BASE={base}
test -n "$DST"
test "$DST" != "/"
test -d "$DST"
test ! -L "$DST"
test -f "$DST/{meta}"
rm -rf "$DST"
sync
test ! -e "$DST"
rmdir "$BASE" 2>/dev/null || true
echo 'BACKUP_DELETED'
""".format(dst=shq(backup_dir), base=shq(base), meta=INTERNAL_BACKUP_META)
        self.connect_container(self.delete_backup_data, self.internal_delete_closed)
        self.container.execute("/bin/sh -c %s" % shq(script))

    def internal_delete_closed(self, rc):
        self.busy = False
        pending = self.pending_delete
        self.pending_delete = None
        if not pending or pending[0] != "internal":
            return
        _, source, backup_dir = pending
        deleted = (rc == 0 and not os.path.lexists(backup_dir))
        if deleted:
            st = load_state()
            if st.get("backup_mode") == "internal":
                try:
                    if os.path.exists(STATE_FILE):
                        os.unlink(STATE_FILE)
                except Exception:
                    save_state({"backup_mode": "internal", "source_slot": source, "verified": False, "deleted": datetime.now().strftime("%d.%m.%Y %H:%M")})
            self.backup_verified = False
            self.verified_backup_slot = None
            self.verified_backup_mode = None
            self.verified_backup_path = ""
            self.recovery_state = None
            self.set_backup_progress(0, "Backup-Fortschritt", "Status: Internes Backup gelöscht – Update gesperrt.")
            self["rollback"].setText("Noch kein Backup vorhanden.")
            self.append_log("> KILLSWITCH: Internes eMMC-Backup sauber gelöscht. Alle Slots blieben unangetastet.")
            self.refresh_slots()
            self.paint_update_state()
            self.session.open(MessageBox, "Internes Sicherheitsbackup wurde sauber gelöscht.\n\nKein Multiboot-Slot und keine Kernelpartition wurden verändert.\nDas Update ist wieder gesperrt.", MessageBox.TYPE_INFO)
            return

        self.backup_verified = False
        self.verified_backup_mode = None
        self.append_log("> KILLSWITCH FEHLER: Internes Backup wurde nicht vollständig gelöscht.")
        self.set_backup_progress(0, "Backup-Fortschritt – FEHLER", "Status: Löschen unvollständig – Update gesperrt.")
        self.paint_update_state()
        self.session.open(MessageBox, "Internes Backup konnte nicht vollständig gelöscht werden.\nDas Update bleibt gesperrt.", MessageBox.TYPE_ERROR)

    def request_delete_backup(self):
        """Safely remove only the verified SafeUpdate backup tree; keep STARTUP_N intact."""
        if self.busy:
            return
        if self.verified_backup_mode == "internal" or (isinstance(self.recovery_state, dict) and self.recovery_state.get("backup_mode") == "internal"):
            self.request_delete_internal_backup()
            return
        if not self.backup_verified or self.verified_backup_slot is None:
            self.session.open(
                MessageBox,
                "Kein verifiziertes SafeUpdate-Backup zum Löschen vorhanden.",
                MessageBox.TYPE_INFO,
            )
            return

        st = load_state()
        try:
            target = int(self.verified_backup_slot)
        except Exception:
            target = -1
        source = current_slot()

        # Fail closed: only the exact backup recorded and physically revalidated by SafeUpdate may be deleted.
        if (
            target < 0 or
            target == source or
            not st.get("verified") or
            int(st.get("target_slot", -1)) != target or
            int(st.get("source_slot", -1)) != source
        ):
            self.append_log("> KILLSWITCH blockiert: Backup-Zuordnung nicht eindeutig.")
            self.session.open(
                MessageBox,
                "Löschen blockiert. Das gespeicherte Backup ist nicht eindeutig dem laufenden Slot zugeordnet.",
                MessageBox.TYPE_ERROR,
            )
            return

        info = compatible_startup_slots().get(target)
        mp = ensure_full_mount(True)
        if not info or not mp:
            self.append_log("> KILLSWITCH blockiert: Slot/Dateisystem nicht sicher verifizierbar.")
            self.session.open(
                MessageBox,
                "Löschen blockiert. Zielslot oder Dateisystem konnte nicht sicher verifiziert werden.",
                MessageBox.TYPE_ERROR,
            )
            return

        dst = os.path.join(mp, info["rootsubdir"])
        mp_real = os.path.realpath(mp)
        dst_real = os.path.realpath(dst)
        expected_suffix = "linuxrootfs%d" % target
        safe_path = (
            dst_real.startswith(mp_real.rstrip("/") + "/") and
            os.path.basename(dst_real) == expected_suffix and
            not os.path.islink(dst) and
            os.path.isdir(dst) and
            slot_root_tree_valid(dst) and
            os.path.isfile(os.path.join(dst, "etc", "image-version")) and
            os.path.exists(os.path.join(dst, "sbin", "init")) and
            os.path.isfile(os.path.join(dst, "usr", "bin", "enigma2"))
        )
        if not safe_path:
            self.append_log("> KILLSWITCH blockiert: Slot %d besteht Sicherheitsprüfung nicht." % target)
            self.session.open(
                MessageBox,
                "Löschen blockiert. Slot %d besteht die Sicherheitsprüfung nicht." % target,
                MessageBox.TYPE_ERROR,
            )
            return

        self.session.openWithCallback(
            lambda yes: self.do_delete_backup(yes, target, dst),
            MessageBox,
            "KILLSWITCH: Backup in Slot %d wirklich löschen?\n\n"
            "Gelöscht wird NUR das von SafeUpdate verifizierte linuxrootfs%d-Verzeichnis.\n"
            "STARTUP_%d bleibt erhalten, damit der Slot danach wieder sauber FREI ist.\n\n"
            "Das OpenATV-Update wird anschließend wieder gesperrt." % (target, target, target),
            MessageBox.TYPE_YESNO,
        )

    def do_delete_backup(self, yes, target, dst):
        if not yes:
            return
        if self.busy:
            return

        # Final race check immediately after confirmation.
        info = compatible_startup_slots().get(int(target))
        mp = ensure_full_mount(True)
        if not info or not mp:
            self.session.open(MessageBox, "Löschen abgebrochen: Slot konnte nicht erneut geprüft werden.", MessageBox.TYPE_ERROR)
            return
        current_dst = os.path.join(mp, info["rootsubdir"])
        if os.path.realpath(current_dst) != os.path.realpath(dst) or int(target) == current_slot():
            self.session.open(MessageBox, "Löschen abgebrochen: Slot-Zuordnung hat sich geändert.", MessageBox.TYPE_ERROR)
            return

        self.busy = True
        self.backup_verified = False
        self.paint_update_state()
        self.pending_delete = (int(target), current_dst)
        self.set_backup_progress(0, "Backup-Fortschritt – Löschen", "Status: Lösche Sicherheitsbackup aus Slot %d ..." % target)
        self.append_log("> KILLSWITCH: Lösche verifiziertes Backup aus Slot %d ..." % target)

        if is_gbtrio4k():
            script = """
set -e
DST={dst}
test -n "$DST"
test "$DST" != "/"
test -d "$DST"
test ! -L "$DST"
test -f "$DST/etc/image-version"
test -e "$DST/sbin/init"
test -f "$DST/usr/bin/enigma2"
rm -rf "$DST"
sync
test ! -e "$DST"
echo 'BACKUP_DELETED'
""".format(dst=shq(current_dst))
        else:
            script = """
set -e
DST={dst}
test -n "$DST"
test "$DST" != "/"
test -d "$DST"
test ! -L "$DST"
test -f "$DST/zImage"
test -f "$DST/etc/image-version"
rm -rf "$DST"
sync
test ! -e "$DST"
echo 'BACKUP_DELETED'
""".format(dst=shq(current_dst))

        self.connect_container(self.delete_backup_data, self.delete_backup_closed)
        self.container.execute("/bin/sh -c %s" % shq(script))

    def delete_backup_data(self, data):
        try:
            txt = data.decode("utf-8", "replace")
        except Exception:
            txt = str(data)
        for line in txt.splitlines():
            self.append_log("> " + line)

    def delete_backup_closed(self, rc):
        self.busy = False
        pending = self.pending_delete
        self.pending_delete = None
        if not pending:
            return
        target, dst = pending

        deleted = (rc == 0 and not os.path.lexists(dst))
        if deleted:
            try:
                if os.path.exists(STATE_FILE):
                    os.unlink(STATE_FILE)
            except Exception:
                # If state cleanup fails, overwrite it fail-closed so a stale verified state can never unlock updates.
                save_state({
                    "source_slot": current_slot(),
                    "target_slot": target,
                    "verified": False,
                    "deleted": datetime.now().strftime("%d.%m.%Y %H:%M"),
                })
            self.backup_verified = False
            self.verified_backup_slot = None
            self.set_backup_progress(0, "Backup-Fortschritt", "Status: Backup aus Slot %d gelöscht – Update gesperrt." % target)
            self["rollback"].setText("Noch kein Backup vorhanden.")
            self.append_log("> KILLSWITCH: Slot %d sauber gelöscht. STARTUP_%d blieb erhalten." % (target, target))
            self.refresh_slots()
            if target in self.slots:
                self.slot_index = self.slots.index(target)
                self["targetSlot"].setText("Slot %d – FREI" % target)
            self.paint_update_state()
            self.session.open(
                MessageBox,
                "Backup in Slot %d wurde sauber gelöscht.\n\nSTARTUP_%d blieb erhalten. Der Slot ist wieder frei und das Update ist gesperrt." % (target, target),
                MessageBox.TYPE_INFO,
            )
            return

        # A failed rm can leave a partial image. Never call that slot free automatically.
        self.append_log("> KILLSWITCH FEHLER: Slot %d wurde nicht vollständig gelöscht." % target)
        st = load_state()
        st["verified"] = False
        st["invalidated"] = datetime.now().strftime("%d.%m.%Y %H:%M")
        save_state(st)
        self.backup_verified = False
        self.verified_backup_slot = None
        self.set_backup_progress(0, "Backup-Fortschritt – FEHLER", "Status: Löschen unvollständig – Slot %d NICHT verwenden." % target)
        self["rollback"].setText("Backup-Löschung unvollständig.\nSlot %d NICHT verwenden." % target)
        self.paint_update_state()
        self.session.open(
            MessageBox,
            "Backup konnte nicht vollständig gelöscht werden.\n\nSlot %d wird NICHT als frei behandelt. Bitte Details prüfen." % target,
            MessageBox.TYPE_ERROR,
        )

    def restore_internal_backup(self):
        if self.busy:
            return
        state = self.recovery_state
        if not isinstance(state, dict) or state.get("backup_mode") != "internal":
            found = discover_internal_backups()
            state = found[0] if found else None
        if state is None:
            self.session.open(MessageBox, "Kein verifiziertes internes Notfall-Backup vorhanden.", MessageBox.TYPE_INFO)
            return

        mp = ensure_full_mount(True)
        checked = validate_internal_backup_state(state, mp) if mp else None
        if checked is None:
            self.session.open(MessageBox, "Wiederherstellung blockiert: Backup ist nicht mehr vollständig verifizierbar.", MessageBox.TYPE_ERROR)
            return
        source = int(checked.get("source_slot"))
        current = current_slot()
        if current == source:
            self.session.open(MessageBox, "Slot %d läuft gerade.\n\nEin laufender Slot wird niemals über sich selbst wiederhergestellt. Bitte zuerst einen anderen Slot booten." % source, MessageBox.TYPE_INFO)
            return
        info = compatible_startup_slots().get(source)
        if not info or current is None:
            self.session.open(MessageBox, "Zielslot konnte nicht sicher aus STARTUP_N bestimmt werden.", MessageBox.TYPE_ERROR)
            return
        target = os.path.join(mp, info["rootsubdir"])
        active = active_source_path(mp)
        if not active or os.path.realpath(target) == os.path.realpath(active):
            self.session.open(MessageBox, "Wiederherstellung blockiert: Ziel würde den laufenden Slot treffen.", MessageBox.TYPE_ERROR)
            return
        expected = os.path.realpath(os.path.join(mp, "linuxrootfs%d" % source))
        if os.path.realpath(target) != expected or not expected.startswith(os.path.realpath(mp).rstrip("/") + "/"):
            self.session.open(MessageBox, "Wiederherstellung blockiert: Zielpfad ist nicht eindeutig.", MessageBox.TYPE_ERROR)
            return
        if os.path.lexists(target) and (not os.path.isdir(target) or os.path.islink(target)):
            self.session.open(MessageBox, "Wiederherstellung blockiert: Ziel ist kein normales Slot-Verzeichnis.", MessageBox.TYPE_ERROR)
            return
        if is_gbtrio4k():
            dst_kernel = expected_kernel_device(source)
            if not dst_kernel or dst_kernel == active_kernel_device() or not os.path.exists(dst_kernel):
                self.session.open(MessageBox, "Wiederherstellung blockiert: Kernel-Zielpartition ist nicht sicher.", MessageBox.TYPE_ERROR)
                return

        self.session.openWithCallback(
            lambda yes: self.do_restore_internal_backup(yes, checked),
            MessageBox,
            "NOTFALL-RÜCKKEHR: Slot %d aus dem internen SafeUpdate-Backup wiederherstellen?\n\n"
            "Aktuell läuft Slot %d.\n"
            "Nur Slot %d wird ersetzt; der laufende Slot, andere Images und Recovery bleiben unangetastet." % (source, current, source),
            MessageBox.TYPE_YESNO,
        )

    def do_restore_internal_backup(self, yes, state):
        if not yes or self.busy:
            return
        mp = ensure_full_mount(True)
        checked = validate_internal_backup_state(state, mp) if mp else None
        if checked is None:
            self.session.open(MessageBox, "Wiederherstellung abgebrochen: Backup-Prüfung ist nicht mehr gültig.", MessageBox.TYPE_ERROR)
            return
        source = int(checked.get("source_slot"))
        current = current_slot()
        if current is None or current == source:
            self.session.open(MessageBox, "Wiederherstellung abgebrochen: Zielslot läuft jetzt selbst.", MessageBox.TYPE_ERROR)
            return
        info = compatible_startup_slots().get(source)
        if not info:
            self.session.open(MessageBox, "Wiederherstellung abgebrochen: STARTUP-Zuordnung fehlt.", MessageBox.TYPE_ERROR)
            return
        target = os.path.join(mp, info["rootsubdir"])
        active = active_source_path(mp)
        backup_root = checked.get("_rootfs", "")
        if not active or os.path.realpath(target) == os.path.realpath(active) or not slot_root_tree_valid(backup_root):
            self.session.open(MessageBox, "Wiederherstellung abgebrochen: Sicherheitsprüfung fehlgeschlagen.", MessageBox.TYPE_ERROR)
            return

        self.busy = True
        self.pending_restore = (source, target, checked)
        self.append_log("> NOTFALL-RÜCKKEHR: Stelle Slot %d wieder her ..." % source)
        self.set_backup_progress(5, "Wiederherstellung – Prüfen", "Status: Verifiziertes Backup wird zurückgespielt ...")

        if is_gbtrio4k():
            kernel_file = os.path.join(checked.get("_backup_dir", ""), "kernel.img")
            dst_kernel = expected_kernel_device(source)
            if not dst_kernel or dst_kernel == active_kernel_device():
                self.busy = False
                self.pending_restore = None
                self.session.open(MessageBox, "Kernel-Zielpartition ist nicht sicher.", MessageBox.TYPE_ERROR)
                return
            script = """
set -e
BACKUP={backup}
TARGET={target}
KERNEL_FILE={kernel_file}
DST_KERNEL={dst_kernel}
test -d "$BACKUP"
test -f "$BACKUP/etc/image-version"
test -e "$BACKUP/sbin/init"
test -f "$BACKUP/usr/bin/enigma2"
test -f "$KERNEL_FILE"
test -b "$DST_KERNEL"
test "$TARGET" != "/"
if [ -e "$TARGET" ]; then test -d "$TARGET"; test ! -L "$TARGET"; rm -rf "$TARGET"; fi
mkdir "$TARGET"
echo 'Kopiere Image...'
cp -a "$BACKUP"/. "$TARGET"/
sync
test -f "$TARGET/etc/image-version"
test -e "$TARGET/sbin/init"
test -f "$TARGET/usr/bin/enigma2"
echo 'Stelle GigaBlue Kernel wieder her...'
dd if="$KERNEL_FILE" of="$DST_KERNEL" bs=1048576 conv=fsync 2>/dev/null
sync
SRC_HASH=$(sha256sum "$KERNEL_FILE" | awk '{{print $1}}')
DST_HASH=$(sha256sum "$DST_KERNEL" | awk '{{print $1}}')
[ -n "$SRC_HASH" ]
[ "$SRC_HASH" = "$DST_HASH" ] || exit 22
echo 'RESTORE_VERIFIED'
""".format(backup=shq(backup_root), target=shq(target), kernel_file=shq(kernel_file), dst_kernel=shq(dst_kernel))
        else:
            script = """
set -e
BACKUP={backup}
TARGET={target}
test -d "$BACKUP"
test -f "$BACKUP/zImage"
test -f "$BACKUP/etc/image-version"
test "$TARGET" != "/"
if [ -e "$TARGET" ]; then test -d "$TARGET"; test ! -L "$TARGET"; rm -rf "$TARGET"; fi
mkdir "$TARGET"
echo 'Kopiere Image...'
cp -a "$BACKUP"/. "$TARGET"/
sync
SRC_HASH=$(sha256sum "$BACKUP/zImage" | awk '{{print $1}}')
DST_HASH=$(sha256sum "$TARGET/zImage" | awk '{{print $1}}')
[ -n "$SRC_HASH" ]
[ "$SRC_HASH" = "$DST_HASH" ] || exit 22
echo 'RESTORE_VERIFIED'
""".format(backup=shq(backup_root), target=shq(target))

        self.connect_container(self.restore_data, self.restore_closed)
        self.container.execute("/bin/sh -c %s" % shq(script))

    def restore_data(self, data):
        try:
            txt = data.decode("utf-8", "replace")
        except Exception:
            txt = str(data)
        for line in txt.splitlines():
            self.append_log("> " + line)
            low = line.lower()
            if "kopiere image" in low:
                self.set_backup_progress(30, "Wiederherstellung – Kopieren", "Status: Slot wird aus Sicherheitsbackup wiederhergestellt ...")
            elif "stelle gigablue kernel" in low:
                self.set_backup_progress(90, "Wiederherstellung – Kernel", "Status: Kernel wird verifiziert zurückgespielt ...")
            elif "restore_verified" in low:
                self.set_backup_progress(99, "Wiederherstellung – Verifizieren", "Status: Abschlussprüfung ...")

    def restore_closed(self, rc):
        self.busy = False
        pending = self.pending_restore
        self.pending_restore = None
        if not pending:
            return
        source, target, state = pending
        ok = (rc == 0 and slot_root_tree_valid(target))
        if ok and is_gbtrio4k():
            kernel_hash = state.get("kernel_sha256", "")
            ok = bool(kernel_hash and sha256_prefix(expected_kernel_device(source)) == kernel_hash)
        elif ok:
            ok = sha256_prefix(os.path.join(target, "zImage")) == state.get("kernel_sha256", "")
        if ok:
            self.set_backup_progress(100, "Wiederherstellung – Fertig", "Status: Slot %d erfolgreich wiederhergestellt." % source)
            self.append_log("> NOTFALL-RÜCKKEHR: Slot %d erfolgreich verifiziert wiederhergestellt." % source)
            self.session.open(MessageBox, "Slot %d wurde erfolgreich aus dem internen Sicherheitsbackup wiederhergestellt.\n\nDu kannst jetzt in Slot %d booten. Das Sicherheitsbackup bleibt erhalten." % (source, source), MessageBox.TYPE_INFO)
        else:
            self.set_backup_progress(0, "Wiederherstellung – FEHLER", "Status: Wiederherstellung nicht vollständig verifiziert.")
            self.append_log("> NOTFALL-RÜCKKEHR FEHLER: Slot %d nicht verifiziert." % source)
            self.session.open(MessageBox, "Wiederherstellung konnte nicht vollständig verifiziert werden.\nDas interne Sicherheitsbackup wurde NICHT gelöscht und kann erneut verwendet werden.", MessageBox.TYPE_ERROR)

    def toggle_rotation(self):
        if self.busy:
            return
        if not rotation_layout_supported():
            self.session.open(
                MessageBox,
                "Auto-Rotation ist auf dieser Box sicher deaktiviert.\n\nDas Box-/Slot-Layout ist für r33 noch nicht freigegeben. Normales Backup, Update, Killswitch und Rollback bleiben verfügbar.",
                MessageBox.TYPE_INFO,
            )
            return
        state = physically_verified_rotation_state()
        if state is None:
            self.session.open(MessageBox, "Auto-Rotation kann erst mit einem verifizierten Backup verwendet werden.", MessageBox.TYPE_INFO)
            return
        state = ensure_rotation_state(state)
        enabled = not bool(state.get("rotation_enabled", False))
        now = int(time.time())
        state["rotation_enabled"] = enabled
        state["rotation_last_check"] = now
        state["rotation_last_error"] = ""
        state["rotation_next_due"] = now + ROTATION_INTERVAL if enabled else 0
        if not state.get("system_fingerprint"):
            state["system_fingerprint"] = current_system_fingerprint()
        persist_rotation_state(state)
        self["backupStatus"].setText(rotation_status_text(state))
        self.append_log("> Auto-Rotation 24h: %s" % ("EIN" if enabled else "AUS"))
        self.session.open(
            MessageBox,
            "Automatische Backup-Rotation ist jetzt %s.\n\nPrüfintervall: 24 Stunden.\nEin Vollbackup wird nur erstellt, wenn sich der Systemstand geändert hat." % ("EIN" if enabled else "AUS"),
            MessageBox.TYPE_INFO,
        )

    def force_rotation_now(self):
        if self.busy:
            return
        if not rotation_layout_supported():
            self.session.open(
                MessageBox,
                "Rotation ist auf dieser Box blockiert.\n\nDas Box-/Slot-Layout ist für r33 noch nicht freigegeben; es wird nichts verändert.",
                MessageBox.TYPE_INFO,
            )
            return
        state = physically_verified_rotation_state()
        if state is None:
            self.session.open(MessageBox, "Für den Rotationstest wird zuerst ein verifiziertes SafeUpdate-Backup benötigt.", MessageBox.TYPE_INFO)
            return
        self.session.openWithCallback(
            self._force_rotation_confirmed,
            MessageBox,
            "Backup-Rotation JETZT starten?\n\nDas bisherige verifizierte Backup bleibt bestehen, bis die neue Kopie vollständig geprüft ist.\nErst danach wird das alte Backup ersetzt.",
            MessageBox.TYPE_YESNO,
        )

    def _force_rotation_confirmed(self, yes):
        if not yes:
            return
        get_rotation_service(self.session).check(True, self)


    def start_update(self):
        if self.busy:
            self.session.open(
                MessageBox,
                "Update ist gesperrt, solange ein Sicherheitsvorgang läuft.",
                MessageBox.TYPE_INFO,
            )
            return
        if not self.backup_verified:
            self.session.open(MessageBox, "Update bleibt gesperrt, bis ein Backup erfolgreich verifiziert wurde.", MessageBox.TYPE_INFO)
            return
        if not kexec_ok():
            self.session.open(MessageBox, "KEXEC-Kernel ist nicht korrekt. Update wird blockiert.", MessageBox.TYPE_ERROR)
            return
        if not holds_ok():
            if is_gbtrio4k():
                self.append_log("> Setze GigaBlue Kernel-Pakete auf HOLD...")
                if not ensure_kernel_holds():
                    self.session.open(MessageBox, "GigaBlue Kernel-Pakete konnten nicht sicher auf HOLD gesetzt werden. Update wird blockiert.", MessageBox.TYPE_ERROR)
                    return
                self.refresh_status()
            else:
                self.session.open(MessageBox, "Nicht alle Kernel-Pakete stehen auf HOLD. Update wird blockiert.", MessageBox.TYPE_ERROR)
                return
        self.session.openWithCallback(self.do_update, MessageBox, "Backup ist verifiziert.\n\nOpenATV jetzt mit opkg update && opkg upgrade aktualisieren?", MessageBox.TYPE_YESNO)

    def do_update(self, yes):
        if not yes:
            return
        self.busy = True
        self.append_log("> opkg update")
        hold_cmd = "; ".join("opkg flag hold %s >/dev/null 2>&1 || true" % shq(p) for p in kernel_packages())
        cmd = "set -e; %s; opkg update; echo __SAFEUPDATE_UPGRADE__; opkg upgrade" % hold_cmd
        self.connect_container(self.update_data, self.update_closed)
        self.container.execute("/bin/sh -c %s" % shq(cmd))

    def update_data(self, data):
        try:
            txt = data.decode("utf-8", "replace")
        except Exception:
            txt = str(data)
        for line in txt.splitlines():
            if line == "__SAFEUPDATE_UPGRADE__":
                self.append_log("> opkg upgrade")
            else:
                self.append_log("> " + line[:120])

    def update_closed(self, rc):
        self.busy = False
        self.append_log("> Update-Prozess beendet. RC=%s" % rc)
        guard_ok = True
        if (not is_gbtrio4k()) and os.path.isfile("/usr/local/sbin/kexec-guard.sh"):
            guard_ok = subprocess.call(["/usr/local/sbin/kexec-guard.sh"]) == 0
        self.refresh_status()
        if rc == 0 and guard_ok and kexec_ok():
            post_update_rotation_delay()
            self.append_log("> Sicherheitsprüfung: OK")
            self.append_log("> Auto-Rotation: Vor-Update-Backup bleibt mindestens 24h erhalten.")
            self.session.open(MessageBox, "Update abgeschlossen.\nKEXEC-Schutz ist weiterhin OK.\n\nNeustart bitte anschließend manuell ausführen.", MessageBox.TYPE_INFO)
        else:
            self.append_log("> WARNUNG: Update/Sicherheitsprüfung nicht sauber beendet.")
            self.session.open(MessageBox, "Update oder Sicherheitsprüfung meldet einen Fehler.\nBitte NICHT neu starten, bevor die Details geprüft wurden.", MessageBox.TYPE_ERROR)

    def show_details(self):
        info = image_info()
        st = load_state()
        verified_state = physically_verified_rotation_state(st)
        if verified_state is not None:
            st = ensure_rotation_state(verified_state)
        mode = st.get("backup_mode") or ("internal" if not self.slots else "slot")
        if rotation_layout_supported():
            auto_text = "EIN / 24h" if st.get("rotation_enabled", False) else "AUS"
            next_text = rotation_time_text(st.get("rotation_next_due", 0)) if st.get("rotation_enabled", False) else "-"
        else:
            auto_text = "NICHT VERFÜGBAR"
            next_text = "-"
        text = (
            "%s %s\n\n"
            "Aktueller Slot: %s\n"
            "Image: %s\n"
            "Build: %s\n"
            "Root: %s\n\n"
            "KEXEC: %s\n"
            "Kernel-HOLDs: %s\n"
            "HDD /media/usb: %s\n"
            "Verifiziert freie Slots: %s\n\n"
            "Backup-Modus: %s\n"
            "Letztes Backup: %s\n"
            "Auto-Rotation: %s\n"
            "Nächste Prüfung: %s\n\n"
            "7 = Rotation jetzt testen\n"
            "8 = Auto-Rotation EIN/AUS"
        ) % (
            PLUGIN_NAME, PLUGIN_VERSION,
            current_slot() if current_slot() is not None else "?",
            info.get("version", "?"), info.get("build", "?"), root_device() or "?",
            "OK" if kexec_ok() else "FEHLER", "OK" if holds_ok() else "FEHLER", "OK" if hdd_ok() else "FEHLER",
            ", ".join(str(x) for x in self.slots) or "keine", mode, st.get("created", "keins"), auto_text, next_text
        )
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO)


def main(session, **kwargs):
    session.open(SafeUpdateScreen)


def Plugins(**kwargs):
    return [
        PluginDescriptor(name=PLUGIN_NAME, description="Backup + sicheres OpenATV Update für KEXEC-Multiboot", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main),
        PluginDescriptor(name=PLUGIN_NAME, description="Backup + sicheres OpenATV Update für KEXEC-Multiboot", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=rotation_sessionstart),
    ]
