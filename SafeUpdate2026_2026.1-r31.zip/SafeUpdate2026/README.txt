SafeUpdate2026 2026.1-r31
=========================

GigaBlue UHD Trio 4K: STARTUP-Parser akzeptiert die echte quoted boot-Syntax.
root=/dev/mmcblk0p16 wird auch direkt nach dem fuehrenden Hochkomma erkannt.
Slot-/Kernel-, Backup-, Killswitch- und Update-Sicherheitslogik aus r30 bleibt unveraendert.
