SafeUpdate2026 2026.1-r33-dev2
==============================

Hardware-Teststand auf Basis des auf VU+ Duo 4K SE bestaetigten r33-dev1.

Neu in dev2:
- Update-Bereich wird waehrend Backup oder Auto-Rotation sichtbar ROT gesperrt.
- Text: UPDATE GESPERRT – BACKUP LAEUFT.
- Hinweis: Sicherheitsbackup wird erstellt und verifiziert.
- Gruen/OK kann waehrend eines laufenden Sicherheitsvorgangs kein Update starten.
- Auch Loeschen und Wiederherstellung zeigen einen roten Sicherheits-Lock.
- Nach Ende des Vorgangs kehrt die Anzeige automatisch in den normalen Zustand zurueck.

r33-dev1 Funktionen bleiben erhalten:
- r32 Unterbau inklusive internem eMMC-Fallback und GigaBlue-Schutz
- Killswitch 0 und Notfall-Restore 9
- 24h Auto-Rotation
- Taste 7 manueller Rotationstest, Taste 8 Auto EIN/AUS
- altes verifiziertes Backup bleibt bis zur Verifikation der neuen Kopie bestehen
- Hintergrunddienst funktioniert bei geschlossenem Plugin und normalem Standby
