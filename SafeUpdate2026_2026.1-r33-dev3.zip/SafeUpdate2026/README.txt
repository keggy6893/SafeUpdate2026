SafeUpdate2026 2026.1-r33-dev3
==============================

Sicherer r33-Releasekandidat auf Basis des hardwarebestaetigten VU+-dev2.

Neu in dev3:
- Auto-Rotation ist fail-closed und nur auf explizit freigegebenen Layouts aktiv.
- Freigegeben: VU+ Duo 4K SE und GigaBlue UHD Trio 4K.
- Unbekannte/andere Boxen: Auto-Rotation und Taste 7/8 sind sicher deaktiviert.
- Normales Backup, Update, Killswitch und Rollback bleiben auf solchen Boxen unveraendert verfuegbar.
- Auf nicht freigegebenen Boxen wird kein Auto-Rotations-Hintergrundtimer gestartet.
- Alte dev1/dev2 Rotationszustaende werden auf unbekannten Boxen automatisch auf AUS gesetzt.
- SF8008 bleibt bis zum separaten Hardwaretest von r33-Auto-Rotation ausgeschlossen.

Beibehalten:
- roter technischer Update-Lock waehrend Backup/Rotation/Loeschen/Wiederherstellung
- 24h-Pruefung, Fingerprint-Skip und sichere Backup-Rotation auf freigegebenen Layouts
- internes eMMC-Fallback, GigaBlue Kernel-Schutz, Killswitch 0 und Notfall-Restore 9
