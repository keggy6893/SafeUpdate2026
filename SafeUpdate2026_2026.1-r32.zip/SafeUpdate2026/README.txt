SafeUpdate2026 2026.1-r32
=========================

Neu: internes eMMC-Sicherheitsbackup als automatischer Fallback, wenn kein freier Multiboot-Slot vorhanden ist.

- Kein USB-Datentraeger erforderlich.
- Vorhandene linuxrootfs-Slots werden nicht ueberschrieben.
- Recovery/Root-Image wird nie als Backup-Ziel benutzt.
- Backup liegt separat im gemeinsamen Multiboot-Dateisystem unter /safeupdate2026/slotN.
- GigaBlue: RootFS plus separate Kernelpartition werden in RootFS + kernel.img gesichert und per SHA256 verifiziert.
- Erst nach erfolgreicher Verifikation wird das OpenATV-Update freigegeben.
- Killswitch Taste 0 loescht im internen Modus ausschliesslich /safeupdate2026/slotN.
- Notfall-Rueckkehr: von einem anderen Slot booten; Taste 9 stellt den gesicherten Quellslot wieder her.
- Der laufende Slot kann niemals ueber sich selbst wiederhergestellt werden.
- Bestehender bootfaehiger Slot-Backup-Modus bleibt erhalten, wenn ein freier Slot vorhanden ist.
- GigaBlue r30/r31 Kernel-/STARTUP-Schutz bleibt erhalten.
