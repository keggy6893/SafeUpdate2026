SafeUpdate2026 2026.1-r30
=========================

GigaBlue UHD Trio 4K: native Slot-/Kernel-Unterstuetzung.
Interne Slots 1-4: linuxrootfs1-4 auf /dev/mmcblk0p16.
Kernel: Slot1=p12, Slot2=p13, Slot3=p14, Slot4=p15.
USB STARTUP_5/6 werden nicht als Backup-Ziele verwendet.
Rootfs und separater Kernel werden beim Backup verifiziert.
Kernel-HOLDs nutzen die getesteten 4.4.35-Pakete.
VU+/andere Receiver behalten den r29-Pfad.
